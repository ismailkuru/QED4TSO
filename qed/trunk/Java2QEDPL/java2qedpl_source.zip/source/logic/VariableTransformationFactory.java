package logic;

import syntaxtree.NodeToken;

/**
 * 
 * {@link VariableTransformationFactory} is the Factory pattern for {@link VariableTransformation} creation.
 * 
 * @author Kivanc Muslu
 *
 */
public class VariableTransformationFactory
{
    
    private static VariableTransformationFactory instance_ = new VariableTransformationFactory();
    
    /**
     * Private constructor to create the singleton instance.
     */
    private VariableTransformationFactory()
    {}
    
    /**
     * Returns the instance.
     * @return The instance.
     */
    public static VariableTransformationFactory getInstance()
    {
        return instance_;
    }
    
    /**
     * Creates the resulting {@link VariableTransformation} with the given information.
     * @param isStatic {@code true} if the variable is static, {@code false} otherwise.
     * @param isFinal {@code true} if the variable is final, {@code false} otherwise.
     * @param hasAssignment {@code true} if the variable has an assignment in the declaration, {@code false} otherwise.
     * @param owner Owner container of the variable.
     * @param name Name of the variable.
     * @param assignment Assignment (if any) of the variable.
     * @param arrayDimension If this is not {@code 0}, then the variable represents an array with dimension == arrayDimension
     * @return The resulting VariableTransformation with the given information.
     */
    public VariableTransformation createVariableTransformation(boolean isStatic, boolean isFinal, boolean hasAssignment,
            ContainerTransformation owner, NodeToken name, TransformationExpressionList<TransformationExpression> assignment,
            int arrayDimension)
    {
        VariableTransformation result = null;
        if (arrayDimension == 0)
        {
            if (!hasAssignment)
            {
                if (isStatic && !isFinal)
                    result = new PlainStaticVariableTransformation(owner, name);
                else if (!isStatic && !isFinal)
                    result = new PlainVariableTransformation(owner, name);
            }
            else
            {
                if (isStatic && isFinal)
                    result = new ConstantVariableTransformation(owner, name, assignment);
                else if (isStatic && !isFinal)
                    result = new StaticVariableWithAssignmentTransformation(owner, name, assignment);
                else if (!isStatic && !isFinal)
                    result = new VariableWithAssignmentTransformation(owner, name, assignment);
            }
        }
        else
            result = new ArrayTransformation(owner, name, assignment, arrayDimension);

        return result;
    }
}
