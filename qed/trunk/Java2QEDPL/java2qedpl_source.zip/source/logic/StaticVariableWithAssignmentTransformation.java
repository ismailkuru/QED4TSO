package logic;

import syntaxtree.NodeToken;

/**
 * {@link StaticVariableWithAssignmentTransformation} represents static variable declarations with assignment in Java. <br>
 * It has two elements: variableName which represents the name of the variable, and assignedTo that represents the assignment.<br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC.
 * 
 * @author Kivanc Muslu
 */
public class StaticVariableWithAssignmentTransformation extends PlainStaticVariableTransformation
{
    
    /**
     * Passes the owner container, variableName and assignment to {@link PlainStaticVariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected StaticVariableWithAssignmentTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
    }
    
    /**
     * Transforms and returns the assignment part of the variable. <br>
     * <br>{@inheritDoc}
     * 
     * @see #transform()
     */
    public String transformAssignment()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result += getCompletedVariableName() + " := " + getAssignedTo().transformCompletely() + ";\n";
        return result;
    }
    
    /**
     * <strong>Example Translation (for StaticVariableWithAssignmentTransformation):</strong>
     * 
     * <pre>
     * static int counter = 5; // Assume that counter is defined in MyClass.
     * 
     * ==&gt; is translated to
     * 
     * var MyClass_counter: int;
     * MyClass_counter := 5;
     * </pre>
     * {@inheritDoc}
     * 
     */
    public String transform()
    {
        if (isOnlyAssignmentTransformation())
            return transformAssignment();
        else
            return super.transformCompletely();
    }
    
    /**
     * Overridden to create a new instance of the same translation. Because declaration can be modified and we don't want the
     * actual variable to be modified at the same time. <br>
     * <br>{@inheritDoc}
     */
    public VariableTransformation getDeclaration()
    {
        VariableTransformation result = new PlainStaticVariableTransformation(getOwner(), getNameToken());
        result.setType(getType());
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.StaticVariableWithAssignmentTransformation: name = " + getName() + ", type = " + getType()
                + ", indentation = " + getIndentationLevel() + "]";
    }
    
}
