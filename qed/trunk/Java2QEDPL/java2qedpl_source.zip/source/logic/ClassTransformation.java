package logic;

import java.util.ArrayList;
import java.util.HashSet;

import syntaxtree.NodeToken;

/**
 * {@link ClassTransformation} represents the classes in Java. <br>
 * <strong>Field Summary:</strong></br>
 * methods_ represents the methods of this class. </br>
 * children_ represents the inner classes of this class. </br>
 * exceptions_ represents all exceptions declared in the input programs. </br>
 * MAIN_CLASS_DECLARATION represents the virtual class that represents the whole program. </br>
 * classes_ represents all ClassTransformations that are declared.
 * 
 * @author Kivanc Muslu
 * 
 */
public class ClassTransformation extends ContainerTransformation
{
    private final ArrayList<MethodTransformation> methods_;
    private final ArrayList<ClassTransformation> children_;
    
    private static final HashSet<String> exceptions_ = new HashSet<String>();
    private static final ClassTransformation MAIN_CLASS_DECLARATION = new ClassTransformation("MainClass");
    private static final ArrayList<ClassTransformation> classes_ = new ArrayList<ClassTransformation>();
    
    /**
     * Passes the owner container, and name to {@link ContainerTransformation}.
     * 
     * @param owner Owner container of this class.
     * @param name Name of this class.
     */
    public ClassTransformation(ContainerTransformation owner, NodeToken name)
    {
        super(owner, name, owner == MAIN_CLASS_DECLARATION);
        children_ = new ArrayList<ClassTransformation>();
        methods_ = new ArrayList<MethodTransformation>();
        NodeToken nameToken = new NodeToken(getName());
        
        // Default constructor is added.
        methods_.add(new ConstructorTransformation(this, nameToken, "public"));
        
        classes_.add(this);
    }
    
    /**
     * This constructor is only implemented for the creation of the MAIN_CLASS_DECLARATION, thus it is private. <br>
     * Passes the name to {@link ContainerTransformation}.
     * 
     * @param name Name of this class.
     */
    private ClassTransformation(String name)
    {
        super(name);
        children_ = new ArrayList<ClassTransformation>();
        methods_ = new ArrayList<MethodTransformation>();
    }
    
    /**
     * This method returns the {@link ClassTransformation} (if any exists) that declares the input 'type'.
     * 
     * @param type Type that represents the class.
     * @return The ClassTransformation that represents the type if any, returns {@code null} otherwise.
     */
    public static ClassTransformation getClassTransformation(String type)
    {
        for (ClassTransformation ct : classes_)
        {
            if (ct.getName().equals(type))
                return ct;
        }
        
        return null;
    }
    
    /**
     * Sets the declared class of the variable 'vd' as 'this'. <br>
     * <br> {@inheritDoc}
     */
    public void addVariableTransformation(VariableTransformation vd)
    {
        vd.setDeclaredClass(this);
        super.addVariableTransformation(vd);
    }
    
    /**
     * {@inheritDoc} <br>
     * <br>
     * Returns {@code true} if any of the inner classes of this class contains the variable defined with 'variableName'.
     */
    protected boolean containsVariableDeclaration(String variableName)
    {
        boolean result1 = super.containsVariableDeclaration(variableName);
        if (result1)
            return true;
        
        for (ClassTransformation ct : children_)
        {
            if (ct.containsVariableDeclaration(variableName))
                return true;
        }
        
        return false;
    }
    
    /**
     * {@inheritDoc} <br>
     * <br>
     * Returns the {@link VariableTransformation} represented with 'variableName' if any of the inner classes of this class
     * contains the variable.
     */
    protected VariableTransformation getVariableDeclaration(String variableName)
    {
        VariableTransformation result = super.getVariableDeclaration(variableName);
        if (result != null)
            return result;
        
        for (ClassTransformation ct : children_)
        {
            result = ct.getVariableDeclaration(variableName);
            if (result != null)
                return result;
        }
        
        return null;
    }
    
    /**
     * @param type Type that represents the class that are searched for.
     * @return {@code true} if the type that is searched is declared anywhere in the program, {@code false} otherwise.
     */
    public static boolean containsClassDeclaration(String type)
    {
        for (ClassTransformation ct : classes_)
        {
            if (ct.getName().equals(type))
                return true;
        }
        
        return false;
    }
    
    /**
     * Adds new exception that is represented with 'type'.
     * 
     * @param type Name of the new exception to be added.
     */
    public static void addNewException(String type)
    {
        exceptions_.add(type);
    }
    
    /**
     * @return Main class declaration.
     */
    public static ClassTransformation getMainClassTransformation()
    {
        return MAIN_CLASS_DECLARATION;
    }
    
    /**
     * Returns the matching method that is declared in this class with name = 'originalMethodName' and number of parameters =
     * 'arguments'.
     * 
     * @param originalMethodName Original name of the method that is declared in this class. <br>
     *        With original name the name that is used in the Java code is mentioned (not the QED_PL Translation).
     * @param arguments Number of arguments that the method takes.
     * @return {@link MethodTransformation} that matches the input information and declared in this class. Returns {@code null} if
     *         none exists.
     */
    protected String getCompleteMethodName(String originalMethodName, int arguments)
    {
        for (MethodTransformation method : methods_)
        {
            if (method.getOriginalName().equals(originalMethodName) && method.getNoArguments() == arguments)
                return method.getName();
        }
        // This should never happen!.
        return null;
    }
    
    /**
     * Adds method 'mt' to this class.
     * 
     * @param mt Method to be added.
     */
    public void addMethodTransformation(MethodTransformation mt)
    {
        methods_.add(mt);
    }
    
    /**
     * Adds class 'ct' to this class as a child.
     * 
     * @param ct Class to be added.
     */
    public void addChildTransformation(ClassTransformation ct)
    {
        children_.add(ct);
    }
    
    /**
     * Constructs and returns the translation where the variables (represented with 'filter') are added to the current
     * translation.
     * 
     * @param current Current translation represented as a String.
     * @param filter A {@link VariableTransformation} list that represents the variables to be translated.
     * @return The resulting translation (which includes the translation of the variables).
     */
    private String addVariableToCurrentTransformation(String current, ArrayList<VariableTransformation> filter)
    {
        if (filter.size() == 0)
            return current;
        String result = current;
        for (VariableTransformation vd : filter)
            result += vd.transformCompletely();
        result += "\n";
        return result;
    }
    
    /**
     * Constructs and returns the translation where the constant variables are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the constant variables in the class).
     */
    private String addConstantVariablesToCurrentTransformation(String current)
    {
        ArrayList<VariableTransformation> filter = new ArrayList<VariableTransformation>();
        for (VariableTransformation vd : getVariables())
        {
            if (vd instanceof ConstantVariableTransformation)
                filter.add(vd);
        }
        return addVariableToCurrentTransformation(current, filter);
    }
    
    /**
     * Constructs and returns the translation where the static variables are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the static variables in the class).
     */
    private String addStaticVariablesToCurrentTransformation(String current)
    {
        ArrayList<VariableTransformation> filter = new ArrayList<VariableTransformation>();
        for (VariableTransformation vd : getVariables())
        {
            if (vd instanceof PlainStaticVariableTransformation)
                filter.add(vd);
        }
        return addVariableToCurrentTransformation(current, filter);
    }
    
    /**
     * Constructs and returns the translation where the variable assignments (represented with 'filter') are added to the current
     * translation.
     * 
     * @param current Current translation represented as a String.
     * @param filter A {@link VariableTransformation} list that represents the variable assignments to be translated.
     * @return The resulting translation (which includes the translation of the variable assignments).
     */
    private String addAssignmentsToCurrentTransformation(String current, ArrayList<VariableTransformation> filter)
    {
        String result = current;
        for (VariableTransformation vd : filter)
            result += vd.transformAssignment();
        if (!result.equals(current))
            result += "\n";
        return result;
    }
    
    /**
     * Constructs and returns the translation where the variable assignments of the constant variables (axioms) are added to the
     * current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the variable assignments of the constant variables
     *         (axioms)).
     */
    private String addConstantVariableAxiomsToCurrentTransformation(String current)
    {
        ArrayList<VariableTransformation> filter = new ArrayList<VariableTransformation>();
        for (VariableTransformation vd : getVariables())
        {
            if (vd instanceof ConstantVariableTransformation)
                filter.add(vd);
        }
        return addAssignmentsToCurrentTransformation(current, filter);
    }
    
    /**
     * Constructs and returns the translation where the variable assignments of the static variables are added to the current
     * translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the variable assignments of the static variables).
     */
    private String addStaticVariableAssignmentsToCurrentTransformation(String current)
    {
        ArrayList<VariableTransformation> filter = new ArrayList<VariableTransformation>();
        for (VariableTransformation vd : getVariables())
        {
            if (vd instanceof StaticVariableWithAssignmentTransformation)
                filter.add(vd);
        }
        return addAssignmentsToCurrentTransformation(current, filter);
    }
    
    /**
     * Constructs and returns the translation that represents the QED PL representation of the class declaration (record).
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the declaration of the class).
     */
    private String addRecordToCurrentTransformation(String current)
    {
        // record declaration
        String result = current;
        result += "record " + getName() + "\n{\n";
        for (VariableTransformation vd : getVariables())
        {
            if (vd instanceof PlainVariableTransformation || vd instanceof ArrayTransformation)
            {
                String varTransformation = vd.transformWithIndentation();
                varTransformation = varTransformation.replace("var ", "");
                result += varTransformation;
            }
        }
        result += "}\n\n";
        return result;
    }
    
    /**
     * Transformation of the {@link ClassTransformation} is done with the following steps: <br>
     * <ol>
     * <li>If the class has no owner (i.e., it is the MAIN_CLASS_DECLARATION),</li>
     * <ul>
     * <li>Transform the exceptions declared during the program.</li>
     * <li>Transform the actual classes (children of main class declaration).</li>
     * </ul>
     * <li>If the class has an owner (i.e., represents an actual class from the input program)</li>
     * <ul>
     * <li>For every {@link VariableWithAssignmentTransformation} (non-static variables declared as fields in Java), add the
     * assignment part of this variable as a sentence to each constructor of this class. <br>
     * This is done since QED PL cannot assign non-static class variables and they have to assigned in the constructor.</li>
     * <li>Add the declaration translation of the constant variables to the translation (static, final variables).</li>
     * <li>Add the declaration translation of the static variables to the translation (static, non final variables).</li>
     * <li>Add the assignment translation of the constant variables to the translation (static, final variables).</li>
     * <li>Add the assignment translation of the static variables to the translation (static, non final variables).</li>
     * <li>Add the record translation that represents the class.</li>
     * <li>Add the translation of the methods declared in this class.</li>
     * <li>Add the translation of the inner classes (children of this class).</li>
     * </ul>
     * </ol>
     * 
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        
        if (getOwner() != null)
        {
            for (MethodTransformation method : methods_)
            {
                if (method instanceof ConstructorTransformation)
                {
                    ConstructorTransformation defaultConstructor = (ConstructorTransformation) method;
                    for (VariableTransformation vd : getVariables())
                    {
                        if (vd instanceof VariableWithAssignmentTransformation)
                            defaultConstructor.addTopLevelAssignment(vd);
                    }
                }
            }
            
            result = addConstantVariablesToCurrentTransformation(result);
            result = addStaticVariablesToCurrentTransformation(result);
            result = addConstantVariableAxiomsToCurrentTransformation(result);
            result = addStaticVariableAssignmentsToCurrentTransformation(result);
            
            result = addRecordToCurrentTransformation(result);
            for (MethodTransformation md : methods_)
                result += md.transformWithIndentation() + "\n";
            
            for (ClassTransformation ct : children_)
                result += ct.transform();
        }
        else
        {
            String old = result;
            for (String type : exceptions_)
                result += "const unique " + type + ": Exception;\n";
            if (!old.equals(result))
                result += "\n";
            
            for (ClassTransformation cd : children_)
                result += cd.transformWithIndentation();
        }
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ClassDeclaration: name = " + getName() + ", indentation = " + getIndentationLevel() + "]";
    }
    
}
