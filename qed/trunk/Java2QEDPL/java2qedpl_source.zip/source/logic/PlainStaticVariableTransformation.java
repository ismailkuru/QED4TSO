package logic;

import syntaxtree.NodeToken;

/**
 * {@link PlainStaticVariableTransformation} represents static variable declarations without assignment in Java. <br>
 * It has one element: variableName which represents the name of the variable.<br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC.
 * 
 * @author Kivanc Muslu
 */
public class PlainStaticVariableTransformation extends VariableTransformation
{
    /**
     * Passes the owner container and variableName to {@link VariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     */
    public PlainStaticVariableTransformation(ContainerTransformation owner, NodeToken variableName)
    {
        this(owner, variableName, null);
    }
    
    /**
     * Not to be called by QEDVisitor. This constructor is only called by {@link StaticVariableWithAssignmentTransformation} for
     * inheritance. <br>
     * Passes the owner container, variableName and assignment to {@link VariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected PlainStaticVariableTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
    }
    
    /**
     * Since this is a plain variable, it shouldn't have an assignment and a request to translate assignment returns empty string. <br>
     * <br> {@inheritDoc}
     */
    public String transformAssignment()
    {
        return "";
    }
    
    /**
     * <strong>Example Translation:</strong></br>
     * 
     * <pre>
     * public static int number; // assume that this variable is declared in MyClass
     * 
     * ==&gt; is translated to
     * 
     * var MyClass_number: int;
     * </pre>
     * 
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result += "var " + getCompletedVariableName() + ": " + getTypeName() + ";\n";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.PlainStaticVariableTransformation: name =  " + getName() + ", type = " + getType() + ", indentation = "
                + getIndentationLevel() + "]";
    }
}
