package logic;

import logic.event.UpdateEvent;
import logic.event.UpdateListener;
import syntaxtree.NodeToken;

/**
 * {@link TernaryOperatorTransformation} represents '... ? ... : ...' in Java. <br>
 * It has three elements: condition represents the condition of the ternary operator, success represents the code to be executed
 * if the condition is {@code true} and the failure represents the code to be executed if the condition is {@code false}.<br>
 * 
 * @author Kivanc Muslu
 */
public class TernaryOperatorTransformation extends TransformationExpression implements UpdateEvent
{
    private final TransformationExpressionList<TransformationExpression> condition_;
    private final TransformationExpressionList<TransformationExpression> success_;
    private final TransformationExpressionList<TransformationExpression> failure_;
    
    private NodeToken alias_;
    private String aliasName_;
    
    private NodeToken conditionAlias_;
    private String conditionAliasName_;
    
    /**
     * 
     * Passes the owner container, and condition to {@link TransformationExpression}. <br>
     * Sets the container of condition, success and failure as {@code this}. <br>
     * Adds itself as an event to the method it is declared (since in QED PL there is no ternary operator, so ternary operator
     * must be translated as the syntactic sugar of if ... else).
     * 
     * @param owner Owner container of this expression.
     * @param condition Condition of the if statement.
     * @param success expressions to be executed if the condition is {@code true}.
     * @param failure expressions to be executed if the condition is {@code false}.
     */
    protected TernaryOperatorTransformation(ContainerTransformation owner, NodeToken name,
            TransformationExpressionList<TransformationExpression> condition,
            TransformationExpressionList<TransformationExpression> success,
            TransformationExpressionList<TransformationExpression> failure)
    {
        super(owner, name, false);
        condition_ = condition;
        success_ = success;
        failure_ = failure;
        
        condition.setContainer(this);
        success.setContainer(this);
        failure.setContainer(this);
        
        UpdateListener listener = (UpdateListener) owner;
        listener.addUpdateEvent(this);
    }
    
    /**
     * Since the complete translation is passed to container as pre-translation, only the alias is returned as actual translation. <br>
     * <br>
     * <strong>Example Translation:</strong>
     * 
     * <pre>
     * boolean result = (3 &gt; 4) ? false : true;
     * 
     * ==&gt; is translated to
     * 
     * var dummy: bool;
     * var dummy2: bool;
     * var result: bool;
     * 
     * dummy := (3 &gt; 4);
     * if (dummy)
     * {
     *          dummy2 := false;
     * }
     * else
     * {
     *          dummy2 := true;
     * }
     * result := dummy2;
     * </pre> {@inheritDoc}
     * 
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result += aliasName_;
        return result;
    }
    
    /**
     * Returns the actual translation of the ternary operator. This translation is passed to the container as pre-translation.
     * 
     * @return The actual translation of the ternary operator. This translation is passed to the container as pre-translation.
     * @see #doEvent()
     * @see #transform()
     */
    private String realTransformation()
    {
        String result = "";
        
        String conditionPre = condition_.transformPreTransformation();
        condition_.clearPreTransformation();
        String conditionTransformation = conditionPre + condition_.transformCompletely();
        result += conditionAliasName_ + " := " + conditionTransformation + ";\n";
        result += "if(" + conditionAliasName_ + ")\n";
        result += "{\n";
        
        String successPre = success_.transformPreTransformation();
        success_.clearPreTransformation();
        if (!successPre.trim().equals(""))
        {
            for (String s : successPre.split("\n"))
                result += "\t" + s + "\n";
        }
        result += "\t" + aliasName_ + " := " + success_.transformCompletely() + ";\n";
        result += "}\n";
        result += "else\n";
        result += "{\n";
        String failurePre = failure_.transformPreTransformation();
        failure_.clearPreTransformation();
        if (!failurePre.trim().equals(""))
        {
            for (String s : failurePre.split("\n"))
                result += "\t" + s + "\n";
        }
        result += "\t" + aliasName_ + " := " + failure_.transformCompletely() + ";\n";
        result += "}\n";
        
        clearPreTransformation();
        
        return result;
    }
    
    /**
     * Sets the alias.
     * 
     * @param token Alias to be set.
     */
    private void setAlias(NodeToken token)
    {
        alias_ = token;
        aliasName_ = alias_.tokenImage;
    }
    
    /**
     * Sets alias for condition.
     * 
     * @param token Condition alias to be set.
     */
    private void setConditionAlias(NodeToken token)
    {
        conditionAlias_ = token;
        conditionAliasName_ = conditionAlias_.tokenImage;
    }
    
    /**
     * Return type of ternary operator is defined as the combination of the success' type and failure's type. <br>
     * <br>{@inheritDoc}
     * 
     * @see TypeTransformation#combineTwoTypes(TypeTransformation, TypeTransformation)
     */
    protected TypeTransformation getType()
    {
        TypeTransformation successType = success_.getType();
        TypeTransformation failureType = failure_.getType();
        if (successType.equals(failureType))
            return successType;
        else
        {
            NodeToken nameToken = getNameToken();
            QEDVisitor
                    .writeErrorLog("Ternary operator got two different types for success and failure, combining these two types. @ ("
                            + nameToken.beginLine + ", " + nameToken.beginColumn + ")");
            return TypeTransformation.combineTwoTypes(successType, failureType);
        }
    }
    
    /**
     * Gets two dummy variables from the method this translation declared in. <br>
     * One variable is of type boolean (for the evaluation of the condition variable) and the other one is of the result type of
     * the ternary operator. <br>
     * <br>{@inheritDoc}
     * 
     * @see #realTransformation()
     */
    public void doEvent()
    {
        MethodTransformation method = (MethodTransformation) getOwner();
        String type = getType().transform();
        NodeToken dummyVar = method.addDummyVariable(type);
        setAlias(dummyVar);
        
        NodeToken dummyConditionHolder = method.addDummyVariable("bool");
        setConditionAlias(dummyConditionHolder);
        
        String preTransformation = realTransformation();
        addPreTranslationToContainer(preTransformation);
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.TernaryOperatorTransformation: alias name = " + aliasName_ + "]";
    }
    
}
