package logic;

import syntaxtree.NodeToken;

/**
 * {@link LiteralTransformation} represents all literals (integer, double, boolean, etc.) in Java. <br>
 * It has one elements: name represents the literal itself. <br>
 * Since they are translated directly (with no addition or extra work), they don't need a container.
 * 
 * @author Kivanc Muslu
 */
public class LiteralTransformation extends TransformationExpression
{
    private final TypeTransformation type_;
    
    /**
     * Passes the name to {@link TransformationExpression}. <br>
     * Constructor also assigns the type of the literal. This is done by trying to parse the literal to all known parts in Java.
     * The types are tried from the least general to the most general and the first type that can be parsed from this literal is
     * assigned as its type.
     * 
     * @param name String that represents this {@code Literal}.
     */
    public LiteralTransformation(NodeToken name)
    {
        super(null, name, false);
        
        String type = "";
        String n = name.tokenImage;
        boolean done = false;
        
        if (n.equals("null"))
        {
            type = "none";
            done = true;
        }
        
        if (!done)
        {
            try
            {
                Byte.parseByte(n);
                type = "byte";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            try
            {
                Short.parseShort(n);
                type = "short";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            try
            {
                Integer.parseInt(n);
                type = "int";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            try
            {
                Long.parseLong(n);
                type = "long";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            try
            {
                Float.parseFloat(n);
                type = "float";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            try
            {
                Double.parseDouble(n);
                type = "double";
                done = true;
            }
            catch (Exception e)
            {}
        }
        if (!done)
        {
            if (n.startsWith("\"") && n.endsWith("\""))
            {
                type = "String";
                done = true;
            }
        }
        if (!done)
        {
            try
            {
                Boolean.parseBoolean(n);
                type = "bool";
            }
            catch (Exception e)
            {}
            
        }
        
        if (!done)
            type_ = TypeTransformation.TYPELESS;
        else
            type_ = new TypeTransformation(new NodeToken(type));
    }
    
    /**
     * {@inheritDoc}
     */
    public TypeTransformation getType()
    {
        return type_;
    }
    
    /**
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        return getName();
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.LiteralTransformation: name = " + getName() + ", indentation = " + getIndentationLevel() + "]";
    }
    
}
