package logic;

import java.util.ArrayList;

import logic.event.UpdateEvent;
import logic.event.UpdateListener;
import syntaxtree.NodeToken;

/**
 * {@link ShortCircuitTransformation} is an abstract representation for '&&' and '||' in Java. <br>
 * It has two elements: a list representing the first operand of '&&' and '||' and a list of list than represent the remaining operands.
 * Note: The second element (list of lists) must have at least one element (i.e., '&&' and '||' must have at least two operands). <br>
 * 
 * @author Kivanc Muslu
 */
public abstract class ShortCircuitTransformation extends TransformationExpression implements UpdateEvent
{
    private TransformationExpressionList <TransformationExpression> exp1_;
    private ArrayList<TransformationExpressionList <TransformationExpression>> exp2_;
    
    private NodeToken aliasToken_;
    private String alias_;
    
    /**
     * Passes the owner container to {@link TransformationExpression} and sets the container of all operands as {@code this}. <br>
     * Adds itself as an event to the method it is declared (Since short circuit translations have to be executed as if statements in QED PL).
     * 
     * @param owner Owner container of this expression.
     * @param exp1 First operand of '||' or '&&'.
     * @param exp2 Remaining operands of '||' or '&&'.
     */
    protected ShortCircuitTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> exp1,
            ArrayList <TransformationExpressionList<TransformationExpression>> exp2)
    {
        super(owner);
        exp1_ = exp1;
        exp2_ = exp2;
        
        exp1.setContainer(this);
        for (TransformationExpressionList<TransformationExpression> exp: exp2)
            exp.setContainer(this);
        
        UpdateListener method = (UpdateListener) owner;
        method.addUpdateEvent(this);
    }
    
    /**
     * Returns alias.
     * @return Alias that represents the whole translation.
     */
    protected String getAlias()
    {
        return alias_;
    }
    
    /**
     * Return type of short circuit translations must be boolean. <br>
     * <br>
     * {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return new TypeTransformation(new NodeToken("bool"));
    }
    
    /**
     * Translates and returns the first operand.
     * @return The translation of the first operand.
     * @see ShortCircuitOrTransformation#transform()
     * @see ShortCircuitAndTransformation#transform()
     */
    protected String transformFirstExpression()
    {
        String result = "";
        String preTransformation = exp1_.transformPreTransformation();
        exp1_.clearPreTransformation();

        System.out.println("Tabbed pre: " + preTransformation);
        result += preTransformation;
        String firstTransformation = exp1_.transformCompletely();
        result += alias_ + " := " + firstTransformation + ";\n";
        
        return result;
    }
    
    /**
     * Returns 'n' tabs as a String.
     * @param n Number of tabs to be created.
     * @return 'n' tabs as a String.
     */
    private String tab(int n)
    {
        String result = "";
        for (int a = 0; a < n; a++)
            result += "\t";
        
        return result;
    }
    
    /**
     * Translates and returns the remaining operands.
     * @return The translation of the remaining operands.
     * @see ShortCircuitOrTransformation#transform()
     * @see ShortCircuitAndTransformation#transform()
     */
    protected String transformSecondExpression()
    {
        String result = "";
        for (int a = 0; a < exp2_.size(); a++)
        {
            String preTransformation = exp2_.get(a).transformPreTransformation();
            String tabbedPreTransformation = "";
            exp2_.get(a).clearPreTransformation();
            if (!preTransformation.trim().equals(""))
            {
                for (String line: preTransformation.split("\n"))
                    tabbedPreTransformation += tab(a) + "\t" + line + "\n";
            }
            result += tabbedPreTransformation;
            result += tab(a) + "\t" + alias_ + " := " + exp2_.get(a).transformCompletely() + ";\n";
            if (a+1 < exp2_.size())
            {
                result += tab(a+1) + "if (" + getConditionPrefix() + alias_ + ")\n";
                result += tab(a+1) + "{\n";
            }
        }
        for (int a = exp2_.size()-1; a > 0 ; a--)
            result += tab(a) + "}\n";
        
        return result;
    }
    
    /**
     * Required for the translation of the short circuit translation. Tells how to process the condition of if sentences created by this translation.
     * @return The condition to be applied to the if statements created in the translation.
     */
    protected abstract String getConditionPrefix();
    
    /**
     * Returns the complete translation (which is dependent on the type of short circuit).
     * @return The complete translation.
     */
    // TODO Maybe can get rid of this using 'getConditionPrefix' ???
    public abstract String realTransformation();
    
    /**
     * Translation is the alias since the actual translation is done and passed to the container as a pre-translation. <br>
     * <br>
     * {@inheritDoc}
     */
    public String transform()
    {
        return alias_;
    }
    
    /**
     * Sets alias.
     * @param alias Alias to be set.
     */
    private void setAlias(NodeToken alias)
    {
        aliasToken_ = alias;
        alias_ = aliasToken_.tokenImage;
    }
    
    /**
     * The actual translation is passed to the container as pre-translation. <br>
     * A dummy alias with type boolean is taken from the method that the expression is defined in. <br>
     * This alias is later used as the actual translation of the expression. <br>
     * <br>
     * 
     * {@inheritDoc}
     */
    public void doEvent()
    {
        MethodTransformation method = (MethodTransformation) getOwner();
        NodeToken alias = method.addDummyVariable("bool");
        setAlias(alias);
        
        String preTranslation = "";
        preTranslation = transformPreInitialization();
        clearPreInitialization();
        preTranslation += realTransformation();
        addPreTranslationToContainer(preTranslation);
    } 
    
}
