package logic;

import java.util.ArrayList;

import syntaxtree.NodeToken;

/**
 * {@link VariableTransformation} is an abstract representation for all variables in Java. <br>
 * It has two elements: variableName which represents the name of the variable and assignment which can represent an optional
 * assignment.<br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC.
 * 
 * @author Kivanc Muslu
 */
public abstract class VariableTransformation extends StatementTransformation
{
    private TypeTransformation type_;
    
    private ClassTransformation declaredIn_ = null;
    private Boolean isStatic_ = null;
    private boolean transformOnlyAssingment_;
    
    private static ArrayList<VariableTransformation> variables_ = new ArrayList<VariableTransformation>();
    
    /**
     * Passes the owner container and variableName to {@link StatementTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     */
    protected VariableTransformation(ContainerTransformation owner, NodeToken variableName)
    {
        this(owner, variableName, null);
    }
    
    /**
     * Passes the owner container, variableName and assignment to {@link StatementTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected VariableTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
        transformOnlyAssingment_ = false;
        variables_.add(this);
    }
    
    /**
     * Returns {@code true} is the variable is static, {@code false} otherwise.
     * 
     * @return {@code true} is the variable is static, {@code false} otherwise.
     */
    protected boolean isStatic()
    {
        if (isStatic_ == null)
            isStatic_ = (this instanceof PlainStaticVariableTransformation) || (this instanceof ConstantVariableTransformation);
        
        return isStatic_;
    }
    
    /**
     * Sets the declared class of the variable as {@link ClassTransformation} represented by 'ct'.
     * 
     * @param ct ClassTransformation where this variable is declared in.
     */
    protected void setDeclaredClass(ClassTransformation ct)
    {
        declaredIn_ = ct;
    }
    
    /**
     * Returns where the variable is declared in with lazy initialization.
     * 
     * @return Where the variable is declared in.
     */
    protected ClassTransformation getDeclaredClass()
    {
        if (declaredIn_ == null)
            declaredIn_ = ClassTransformation.getClassTransformation(getType().transform());
        
        return declaredIn_;
    }
    
    /**
     * Forces this variable transformation to translate only the assignment part (if it has any).
     */
    public void transformOnlyAssignment()
    {
        transformOnlyAssingment_ = true;
    }
    
    /**
     * Returns {@code true} if this variable is forced to only translate the assignment part, {@code false} otherwise.
     * 
     * @return {@code true} if this variable is forced to only translate the assignment part, {@code false} otherwise.
     */
    protected boolean isOnlyAssignmentTransformation()
    {
        return transformOnlyAssingment_;
    }
    
    /**
     * Sets type of the variable.
     * 
     * @param type Type to be set.
     */
    public void setType(TypeTransformation type)
    {
        type_ = type;
    }
    
    /**
     * Returns type type of variable. <br>
     * <br> {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return type_;
    }
    
    /**
     * Returns the type of the variable represented as {@link String}.
     * 
     * @return The type of the variable represented as String.
     */
    protected String getTypeName()
    {
        return type_.transformWithIndentation();
    }
    
    /**
     * Returns the complete name of the variable. <br>
     * Complete name of the variable is defined as "class-that-variable-is-declared-in"_"variable-name".
     * 
     * @return The complete name of the variable.
     */
    protected String getCompletedVariableName()
    {
        ContainerTransformation nameOwner = getOwner();
        if (nameOwner == null)
            return getName();
        while (nameOwner instanceof MethodTransformation)
            nameOwner = nameOwner.getOwner();
        return nameOwner.getName() + "_" + getName();
    }
    
    /**
     * Translates and returns the assignment part of the variable with indentation.
     * 
     * @return The translation of the assignment part of the variable with indentation.
     * @see TransformationExpression#transformWithIndentation()
     */
    public String transformAssignmentWithIndentation()
    {
        String result = getIndentedString() + transformPreTransformation();
        result += getIndentedString();
        result += transformAssignment();
        if (result.equals(""))
            return "";
        return result;
    }
    
    /**
     * Assignment translation is dependent to the type of the variable in QED PL. So concrete classes must implement this method.
     * 
     * @return The translation of the assignment part of the variable.
     */
    public abstract String transformAssignment();
    
    /**
     * By default the declaration of a variable transformation is declared as itself. However sub-classes can override this method
     * to return only the declaration part (not the assignment) or return a new instance of the {@code VariableTransformation}.
     * 
     * @return The declaration of the variable.
     */
    public VariableTransformation getDeclaration()
    {
        return this;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.VariableDeclaration: name = " + getName() + ", type = " + getType() + ", owner = " + getOwner().getName()
                + ", indentation = " + getIndentationLevel() + "]";
    }
    
    /**
     * A static debug function that will print all the varialbes declared in the program at the end of the translation.
     */
    public static void printReport()
    {
        System.out.println("=======================================================");
        System.out.println("Variable report:");
        
        for (VariableTransformation variable : variables_)
            System.out.println(variable);
        System.out.println("=======================================================");
    }
    
}
