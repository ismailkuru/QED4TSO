package logic.annotation;

import java.lang.annotation.Annotation;

/**
 * 
 * {@link JAVA2QEDPL_IGNORE} is an {@link Annotation} to be used to ignore some code during the translation process. <br>
 * If this annotation is used before a method or variable, that method or variable is ignored in the translation.
 * 
 * @author Kivanc Muslu
 * 
 */
public @interface JAVA2QEDPL_IGNORE
{}
