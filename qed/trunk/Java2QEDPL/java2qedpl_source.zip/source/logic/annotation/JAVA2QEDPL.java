package logic.annotation;

import java.lang.annotation.Annotation;

/**
 * 
 * {@link JAVA2QEDPL} is an {@link Annotation} to be used to give an optional implementation for the methods in the original code. <br>
 * If this annotation is used before a method, then the body of that method is ignored. <br>
 * Instead, the string array given to the constructor of the annotation is used as the translation of the method. (each element in
 * the array, string, represent one line of code) <br>
 * Method is also declared as 'atomic' for QED PL translation. <br>
 * During the annotation of the method, static members of JAVA2QEDPL can be used to represent some important constants of the
 * method.
 * 
 * @author Kivanc Muslu
 * @see #RESULT
 * @see #THIS
 */
public @interface JAVA2QEDPL
{
    /**
     * In QED PL, return does not take any parameter. To return a value with a function, one must first declare the return alias
     * in prototype and assign that alias in during the function (before it hits a return or the end of the function). <br>
     * RESULT constant can be used to assign return value to the functions that I translate. <br>
     * If you use JAVA2QEDPL.RESULT in your annotation, it is guaranteed that the prototype and the assignment will match (since
     * they use the same constant during the translation). <br>
     * I use Reflection to get the value of RESULT during runtime.
     */
    public static final String RESULT = "functionResult";
    /**
     * In QED PL, to simulate object oriented programming, instance methods take a reference to the instance itself as the first
     * parameter. To access this parameter in the method, one can use JAVA2QEDPL.THIS in the annotation.<br>
     * I use Reflection to get the value of THIS during runtime.
     */
    public static final String THIS = "this";
    
    String[] value();
}
