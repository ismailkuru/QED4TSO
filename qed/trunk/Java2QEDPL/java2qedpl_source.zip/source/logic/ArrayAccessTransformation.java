package logic;

import logic.event.UpdateEvent;
import logic.event.UpdateListener;
import syntaxtree.NodeToken;

/**
 * {@link ArithmeticExpressionTransformation} represents the translation of array accesses in Java. <br>
 * It has 2 elements: First element represents the the array itself, which is a {@link VariableAccessTransformation}, and the
 * index of the array to be accessed, which is a {@link TransformationExpressionList}.
 * <strong>Note: </strong> Array access is only implemented for one dimensional arrays. Arrays with more than one
 * dimension cannot be handled with this class.
 * 
 * @author Kivanc Muslu
 */
public class ArrayAccessTransformation extends TransformationExpression implements UpdateEvent
{
    
    private VariableAccessTransformation arrayAccess_;
    private TransformationExpressionList<TransformationExpression> indexTransformation_;
    
    private NodeToken aliasToken_;
    private String alias_;
    private NodeToken indexAliasToken_;
    private String indexAlias_;
    
    private boolean isLHS_;
    
    /**
     * Passes the owner container to {@link TransformationExpression}, assigns {@code this} as the container of
     * arrayAccess and indexTransformation. <br>
     * This transformation is added to the container method as an event (since the whole translation or index transformation must
     * be translated to a dummy variable before the actual transformation).
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param arrayAccess Transformation expression which represents the array in the original code.
     * @param indexTransformation {@link TransformationExpressionList} which represents (after the translation) the index of the
     *        array.
     */
    protected ArrayAccessTransformation(ContainerTransformation owner, VariableAccessTransformation arrayAccess,
            TransformationExpressionList<TransformationExpression> indexTransformation)
    {
        super(owner);
        arrayAccess_ = arrayAccess;
        indexTransformation_ = indexTransformation;
        
        indexTransformation_.setContainer(this);
        arrayAccess_.setContainer(this);
        
        UpdateListener method = (UpdateListener) owner;
        method.addUpdateEvent(this);
        
        isLHS_ = false;
    }
    
    /**
     * Type of the result of this array access is defined as the element type of the array. Array's type is stored as
     * Array."element_type". So I get the type of the array, split it from '.' and return the last partition. <br>
     * <br> {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        TypeTransformation arrayType = arrayAccess_.getType();
        TypeTransformation result = new TypeTransformation(new NodeToken(arrayType.getName().split("\\.")[0]));
        return result;
    }
    
    /**
     * Makes the array access transformation left hand side. <br>
     * This is important since the translation depends on weather the transformation is left hand side or right hand side. <br>
     * If the transformation is right hand side, then it might be needed to translated to a dummy variable before the actual
     * translation.
     */
    protected void makeLHS()
    {
        isLHS_ = true;
    }
    
    /**
     * Sets the alias.
     * 
     * @param alias Alias that will be used as the result of this translation.
     */
    private void setAlias(NodeToken alias)
    {
        aliasToken_ = alias;
        alias_ = aliasToken_.tokenImage;
    }
    
    /**
     * Sets the index alias.
     * 
     * @param alias Alias that will be used as the result of the index part of this translation.
     */
    private void setIndexAlias(NodeToken alias)
    {
        indexAliasToken_ = alias;
        indexAlias_ = indexAliasToken_.tokenImage;
    }
    
    /**
     * Transformation of the {@link ArrayAccessTransformation} is done with the following steps: <br>
     * <ol>
     * <li>If the translation is right hand side:</li>
     * <ul>
     * <li>Return the alias (since all the translation is done and passed to the container).</li>
     * </ul>
     * <li>If the translation is left hand side:</li>
     * <ul>
     * <li>Put an assertion representing that the index that is accessed is greater or equal than 0 and less then array length</li>
     * <li>Transform the array access.</li>
     * </ul>
     * </ol>
     * <strong>Example translation:</strong>
     * 
     * <pre>
     * numbers[currentNumber + 1] // assuming that 'numbers' is an integer array and 'currentNumber' is an integer. 
     * 
     * ==> translated as (if used as left hand side)
     * 
     * var dummy: int; 
     * dummy := currentNumber + 1; 
     * numbers.elements[dummy] // Notice that dummy has been already assigned to the index of the array. 
     * 
     * translated as (if used as right hand side)
     * 
     * var dummy: int; 
     * var dummy2: int; 
     * dummy := currentNumber + 1; 
     * dummy2 := numbers.element[dummy]; 
     * dummy2 // Notice that the whole translation is represented as an alias. The whole required translations have already been done.
     * </pre>
     * 
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        if (isLHS_)
        {
            String result = "assert 0 <= " + indexAlias_ + " < " + arrayAccess_.transformCompletely() + ".length;\n";
            return result += arrayAccess_.transformCompletely() + ".elements[" + indexAlias_ + "]";
        }
        else
            return alias_;
    }
    
    /**
     * Returns the string representation of this array access transformation.
     * 
     * @return The string representation of this array access transformation.
     */
    private String realTransformation()
    {
        String result = "\n" + alias_ + " := " + arrayAccess_.transformCompletely() + ".elements[" + indexAlias_ + "];";
        return result;
    }
    
    /**
     * If the translation is left hand side, index of the array access is translated beforehand. <br>
     * To do this, a dummy variable (int) is taken from the method (that the array access is used in) and the translation of the
     * index part is assigned to this dummy variable. <br>
     * If the translation is right hand side, in addition to the above, whole translation is assigned to a dummy variable. <br>
     * To do this, a dummy variable (in the type of array element) is taken from the method (that the array access is used in) and
     * the whole translation is assigned to this variable. <br>
     * At the same time, an assertion (saying that the index that will be accessed is greater or equal than 0 and less than the
     * array length) is added before the actual translation. <br>
     * <br> {@inheritDoc}
     */
    public void doEvent()
    {
        MethodTransformation method = (MethodTransformation) getOwner();
        NodeToken indexAlias = method.addDummyVariable("int");
        setIndexAlias(indexAlias);
        
        String preTransformation = indexAlias_ + " := " + indexTransformation_.transformCompletely() + ";";
        
        if (!isLHS_)
        {
            NodeToken alias = method.addDummyVariable(getType().transform());
            setAlias(alias);
            
            preTransformation += "\nassert 0 <= " + indexAlias_ + " < " + arrayAccess_.transformCompletely() + ".length;";
            preTransformation += realTransformation();
        }
        addPreTranslationToContainer(preTransformation);
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ArrayAccessTransformation: array variable = " + arrayAccess_ + "\nIndex = "
                + indexTransformation_.transformCompletely() + ", is LHS = " + isLHS_ + "]";
    }
}
