package logic;

/**
 * {@link ForStatementTransformation} represents for statements in Java. <br>
 * It has four elements: condition represents the condition of the while block, body represents the statements executed in each
 * iteration, initialization represents the translation that must be done before the while, and iteration represents the
 * translations that should be done at the end of the each iteration (these are basically added to the while body). <br>
 * This translation is implemented as a syntactic sugar of {@link WhileStatementTransformation} (with some extra variables).
 * 
 * @see WhileStatementTransformation#transform()
 * 
 * @author Kivanc Muslu
 */
public class ForStatementTransformation extends WhileStatementTransformation
{
    private final TransformationExpressionList<TransformationExpression> initialization_;
    private final TransformationExpressionList<TransformationExpression> iterationStatement_;
    
    /**
     * Passes the owner container, condition and body to {@link WhileStatementTransformation}. <br>
     * Sets the container of initialization and iterationStatement as {@code this}. <br>
     * Also, any variable declared in the initialization of the for statement is marked as assignment only transformation (to
     * prevent double declaration of these variables).
     * 
     * @param owner Owner container of this expression.
     * @param initialization Initialization of the for loop.
     * @param condition Condition of the while statement.
     * @param iterationStatement Iteration statement of the for loop.
     * @param body Body of the while statement.
     */
    protected ForStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> initialization,
            TransformationExpressionList<TransformationExpression> condition,
            TransformationExpressionList<TransformationExpression> iterationStatement,
            TransformationExpressionList<StatementTransformation> body)
    {
        super(owner, condition, body);
        
        initialization_ = initialization;
        iterationStatement_ = iterationStatement;
        
        initialization_.setContainer(this);
        iterationStatement_.setContainer(this);
        
        for (TransformationExpression exp : initialization)
        {
            if (exp instanceof VariableTransformation)
            {
                MethodTransformation method = (MethodTransformation) owner;
                method.addForStatementVariable(exp.getName());
                VariableTransformation variable = (VariableTransformation) exp;
                variable.transformOnlyAssignment();
            }
        }
    }
    
    /**
     * Since the initialization must be executed (translated) before anything else (even the pre-translations), this method is
     * overridden. <br>
     * It first translates the initialization, adds pre-translations and then the remaining translations. <br>
     * <br> {@inheritDoc}
     */
    public String transformCompletely()
    {
        String initializationTransformation = "";
        if (initialization_ != null)
            initializationTransformation += initialization_.transformCompletely();
        
        String result = transform();
        result = initializationTransformation + transformPreTransformation() + result;
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        
        // addPreTransformationToBeginning(initializationTransformation);
        // result += initializationTransformation;
        result += transformUntilTheEnd();
        String iterationTransformation = "";
        if (iterationStatement_ != null)
        {
            iterationTransformation += "\n";
            String temp = iterationStatement_.transformCompletely();
            for (String s : temp.split("\n"))
            {
                if (!s.trim().equals(""))
                    iterationTransformation += "\t" + s + "\n";
            }
        }
        
        if (!iterationTransformation.trim().equals(""))
            result += iterationTransformation.substring(0, iterationTransformation.length() - 1) + ";\n";
        result += transformTheEnd();
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ForStatementTransformation]";
    }
}
