package logic;

import java.lang.reflect.Field;
import java.util.ArrayList;

import logic.event.UpdateEvent;
import logic.event.UpdateListener;

import syntaxtree.NodeToken;

/**
 * {@link VariableAccessTransformation} represents any variable access (including the method names in method calls) in Java. <br>
 * It has one element: name that represents the variable to be accessed. <br>
 * <br>
 * <strong>Field Summary:</strong><br>
 * accessType_ - Represents the type of the access: Must be one of the following: variable, method, or annotation. <br>
 * originalNameToken_ and originalName_ - Represents the access name as in the Java code (name might be modified later on for QED
 * PL translation, however originalName will remain untouched). <br>
 * initialized_ - For access translations (especially method and variable) I do lazy-initialization. During the initialization
 * process (what I call) I link the method or the variable with the actual translation that represents it. This cannot be done
 * always, or might be wrong (due to the fact that I didn't implement all scoping in Java). This cannot be done during parsing too
 * (since that particular method or variable might not be parsed at that moment yet). After this initialization is done, then all
 * information related to this variable access can be easily accessed. <br>
 * lookFor_ - String that represents what variable name is searched during the link process. Used for debugging. <br>
 * alias_ and aliasToken_ - Alias that represents this variable access. Variable accesses must be unrolled if they are global and
 * not left-hand side (i.e. used in an expression). Only used for variable accesses. <br>
 * isLHS_ - if {@code true} variable access is left hand side. Only used for variable accesses. <br>
 * method_ - {@link MethodTransformation} that represents this method access. Only used for method accesses. <br>
 * noArgs_ - Number of arguments for method accesses. Only used for method accesses. To be set by {@link MethodCallTransformation}
 * . <br>
 * variable_ - {@link VariableTransformation} that represents this variable access. Only used for variable accesses. <br>
 * staticAccess_ - Flag that represents if the variable access is a static access or not. Only used for variable accesses. <br>
 * isLocal_ - Flag that represents if the variable access is local or not. Only used for variable accesses. <br>
 * accesses_ - A list that has all the accesses in the original program. Used for debugging. <br>
 * 
 * @author Kivanc Muslu
 * @see #doEvent()
 * @see #setNoArgs(int)
 */
public class VariableAccessTransformation extends TransformationExpression implements UpdateEvent
{
    public static enum AccessType
    {
        VARIABLE, METHOD, ANNOTATION
    };
    
    private AccessType accessType_ = null;
    
    private final NodeToken originalNameToken_;
    private final String originalName_;
    private boolean initialized_ = false;
    private String lookFor_;
    
    private NodeToken aliasToken_;
    private String alias_;
    private boolean isLHS_;
    
    private MethodTransformation method_;
    private int noArgs_;
    
    private VariableTransformation variable_;
    private boolean staticAccess_ = false;
    private boolean isLocal_ = false;
    
    private static ArrayList<VariableAccessTransformation> accesses_ = new ArrayList<VariableAccessTransformation>();
    
    /**
     * Passes the owner and name to {@link TransformationExpression}. <br>
     * Adds itself as an event to the method it is declared (since global accesses must be executed to a dummy variable before the
     * actual translation).
     * 
     * @param owner Owner container of this expression.
     * @param name Name of the access.
     */
    protected VariableAccessTransformation(ContainerTransformation owner, NodeToken name)
    {
        super(owner, name, false);
        originalNameToken_ = name;
        originalName_ = originalNameToken_.tokenImage;
        
        accesses_.add(this);
        
        aliasToken_ = null;
        alias_ = null;
        isLHS_ = false;
        
        // Do a lazy initialization to figure out if the access if Annotation access or not. Annotation accesses' owner must be
        // classes and they are not needed to be added as events. So if the access is not annotation add it as an event. Also
        // since this initialization is a wrong one (done while parsing) set the initialization bit to false.
        initialize();
        if (accessType_ != AccessType.ANNOTATION)
        {
            UpdateListener method = (UpdateListener) owner;
            method.addUpdateEvent(this);
        }
        initialized_ = false;
    }
    
    /**
     * Makes the access left hand side.
     */
    protected void makeLHS()
    {
        isLHS_ = true;
    }
    
    /**
     * Sets the alias.
     * 
     * @param alias Alias to be set.
     */
    private void setAlias(NodeToken alias)
    {
        aliasToken_ = alias;
        alias_ = aliasToken_.tokenImage;
    }
    
    /**
     * Returns the original name (as in Java code).
     * 
     * @return The original name.
     */
    protected String getOriginalName()
    {
        return originalName_;
    }
    
    /**
     * Returns the method that represents the access.
     * 
     * @return The method that represents the access.
     */
    protected MethodTransformation getMethod()
    {
        return method_;
    }
    
    /**
     * Makes the access a method access. To be called by {@link MethodCallTransformation}.
     */
    protected void makeMehodAccess()
    {
        accessType_ = AccessType.METHOD;
    }
    
    /**
     * Sets number of arguments for method accesses. To be called by {@link MethodCallTransformation}
     * 
     * @param noArgs Number of arguments in the method access.
     */
    protected void setNoArgs(int noArgs)
    {
        noArgs_ = noArgs;
    }
    
    /**
     * Type of access translation is defined as variable's type for variable accesses, method's return type for method accesses,
     * and {@code null} for annotations. <br>
     * <br> {@inheritDoc}
     */
    public TypeTransformation getType()
    {
        initialize();
        if (accessType_ == AccessType.METHOD)
            return getMethodReturnType();
        else if (accessType_ == AccessType.VARIABLE)
            return variable_ == null ? TypeTransformation.TYPELESS : variable_.getType();
        
        return null;
    }
    
    /**
     * Returns the method return type for method accesses.
     * 
     * @return The method return type for method accesses.
     */
    protected TypeTransformation getMethodReturnType()
    {
        initialize();
        return method_ == null ? TypeTransformation.TYPELESS : method_.getReturnType();
    }
    
    /**
     * Makes initialization for method accesses. <br>
     * Method name is defined as the last partition of the name split by '.'. <br>
     * This is passed to {@link MethodTransformation#getMethodTransformation(String, int, TypeTransformation...)} to get the
     * correct name and the method itself.
     */
    private void initializeMethodAccess()
    {
        String name = getName();
        String[] temp = name.split("\\.");
        String methodName = temp[temp.length - 1];
        
        MethodTransformation method = MethodTransformation.getMethodTransformation(methodName, noArgs_);
        String correctName = method == null ? name : method.getCompleteName();
        updateName(correctName);
        method_ = method;
    }
    
    /**
     * Does lazy-initialization.
     */
    protected void initialize()
    {
        if (initialized_)
            return;
        
        initialized_ = true;
        
        String name = getName();
        if (name.startsWith("JAVA2QEDPL"))
            accessType_ = AccessType.ANNOTATION;
        else if (accessType_ == AccessType.METHOD)
            initializeMethodAccess();
        else
            initializeVariableAccess();
    }
    
    /**
     * Initializes the access for variables. <br>
     * This is a little tricky due to the scoping rules of Java. <br>
     * To find the correct variable translation that represents this access requires the complete implementation of the scope
     * rules, which I didn't (I think so). <br>
     * <br>
     * Here is what I do for the moment. <br>
     * <ul>
     * <li>If the variable can be found in the first class (following getOwner()s), then it is a global access and done.</li>
     * <li>Else I try to look at the variable one by one starting the first container, till the MAIN_CLASS_DECLARATION. If found,
     * done.</li>
     * <li>However there is still problem if the access is cascaded (i.e. this.coutner.count). In this case one must search count
     * (not the counter). So if something like this happens I search each part (from right to left, split by '.') in the first
     * class that can be found. If any of these parts are found in the class, that is set as variable.</li>
     * </ul>
     */
    private void initializeVariableAccess()
    {
        String name = getName();
        accessType_ = AccessType.VARIABLE;
        ContainerTransformation currentOwner = getOwner();
        while (!(currentOwner instanceof ClassTransformation))
            currentOwner = currentOwner.getOwner();
        
        String[] parts = name.split("\\.");
        String possibleClassName = parts[0];
        if (ClassTransformation.containsClassDeclaration(possibleClassName))
        {
            staticAccess_ = true;
            name = name.substring(name.indexOf(".") + 1, name.length());
        }
        else
            staticAccess_ = false;
        
        if (parts.length == 1 && getOwner().containsVariableDeclaration(name))
        {
            isLocal_ = true;
            variable_ = currentOwner.getVariableDeclaration(name);
        }
        else
            isLocal_ = false;
        
        if (variable_ != null)
            staticAccess_ = variable_.isStatic();
        else
        {
            parts = name.split("\\.");
            String lookFor = parts[0];
            if (lookFor.equals("this") && parts.length > 1)
                lookFor = parts[1];
            lookFor_ = lookFor;
            
            ContainerTransformation temp = getOwner();
            while (temp != null)
            {
                if (temp.containsVariableDeclaration(lookFor))
                {
                    variable_ = temp.getVariableDeclaration(lookFor);
                    if (!variable_.isStatic() && !parts[0].equals("this") && temp == currentOwner)
                        updateName("this." + name);
                    break;
                }
                temp = temp.getOwner();
            }
        }
        
        if (variable_ != null)
            staticAccess_ = variable_.isStatic();
        else
        {
            for (String part : parts)
            {
                if (currentOwner.containsVariableDeclaration(part))
                {
                    variable_ = currentOwner.getVariableDeclaration(part);
                    if (!variable_.isStatic() && !parts[0].equals("this"))
                        updateName("this." + name);
                    else if (!staticAccess_)
                        updateName(variable_.getOwner().getName() + "_" + name);
                    
                    break;
                }
            }
        }
    }
    
    /**
     * Updates method access name in case of an overridden method access. To be called by {@link MethodCallTransformation}. <br>
     * I need to add types of the parameters to this method too. This might return the wrong result for now.
     * 
     * @param arguments Number of arguments to call the method.
     */
    protected void updateMethodAccessName(int arguments)
    {
        initialize();
        if (method_ == null)
        {
            NodeToken name = getNameToken();
            QEDVisitor.writeErrorLog("Cannot update method name for method: " + getName()
                    + ", because cannot find the method transformation that represents it. @ (" + name.beginLine + ", "
                    + name.beginColumn + ")");
            return;
        }
        ClassTransformation cls = (ClassTransformation) method_.getOwner();
        if (cls == null)
        {
            NodeToken name = getNameToken();
            QEDVisitor.writeErrorLog("Cannot update method name for method: " + getName()
                    + ", because cannot find the owner of that method. @ (" + name.beginLine + ", " + name.beginColumn + ")");
            return;
        }
        String correctName = cls.getCompleteMethodName(getName(), arguments);
        updateName(correctName);
    }
    
    /**
     * Returns the complete name to be used during the translation.
     * 
     * @return The complete name to be used during the translation.
     */
    private String getCompleteName()
    {
        initialize();
        
        if (accessType_ == AccessType.VARIABLE)
        {
            if (staticAccess_)
                return getName().replace(".", "_");
            else
                return getName();
        }
        else if (accessType_ == AccessType.METHOD)
        {
            if (method_ == null)
                return getName();
            else
                return method_.getCompleteName();
        }
        else if (accessType_ == AccessType.ANNOTATION)
        {
            String[] parts = getName().split("\\.");
            try
            {
                Class<?> annotationClass = Class.forName("logic.annotation." + parts[0]);
                Field field = annotationClass.getField(parts[1]);
                Object value = field.get(annotationClass);
                return "" + value;
            }
            catch (ClassNotFoundException e)
            {
                e.printStackTrace();
            }
            catch (SecurityException e)
            {
                e.printStackTrace();
            }
            catch (NoSuchFieldException e)
            {
                e.printStackTrace();
            }
            catch (IllegalArgumentException e)
            {
                e.printStackTrace();
            }
            catch (IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        return null;
    }
    
    /**
     * Translation returns the alias if set (if a right hand side variable translation) or the complete name. <br>
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        initialize();
        if (alias_ != null)
            return alias_;
        else
            return getCompleteName();
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        initialize();
        if (accessType_ == AccessType.VARIABLE)
            return "[logic.VariableAccessTransformation.VariableAccess: name = " + getCompleteName()
                    + ", representing the variable:]\n\t" + variable_;
        else if (accessType_ == AccessType.METHOD)
            return "[logic.VariableAccessTransformation.MethodAccess: name = " + getCompleteName()
                    + ", representing the method:]\n\t" + method_;
        else
            return "[logic.VariableAccessTransformation.AnnotationAccess: name = " + getName() + ", representing an annotation.]";
    }
    
    /**
     * This method too is tricky. It is quite hard to implement since to execute the right hand side variable access to a dummy
     * variable, first one has to figure out the return type of this access. This may fail sometimes (which will write to error
     * log). <br>
     * This is done by following the whole cascaded {@link VariableTransformation} in the access. (i.e., for this.array.length,
     * first this is retrieved (which is not in my case since I don't have a concrete variable for this), then array and then
     * length. <br>
     * This method will surely fail for accesses that come from the standard library (since I don't have them internally
     * represented.). <br>
     * If the following of cascade is successful, then a dummy variable (with the result type of this access) is taken from the
     * method where this access is defined. The actual translation is done to this dummy variable and it is set as translation
     * alias. <br>
     * <br> {@inheritDoc}
     */
    public void doEvent()
    {
        if (isLHS_)
            return;
        
        initialize();
        if (accessType_ == AccessType.VARIABLE && variable_ != null && !isLocal_)
        {
            try
            {
                VariableTransformation result = variable_;
                String name = originalName_;
                while (name.contains("."))
                {
                    String[] parts = name.split("\\.");
                    if (!parts[0].equals("this"))
                    {
                        ClassTransformation declaredClass = result.getDeclaredClass();
                        if (declaredClass == null && parts[1].equals("length"))
                        {
                            result = new PlainVariableTransformation(result.getOwner(), new NodeToken("vt_dummy"));
                            result.setType(new TypeTransformation(new NodeToken("int")));
                        }
                        else
                        {
                            VariableTransformation newResult = declaredClass.getVariableDeclaration(parts[1]);
                            if (newResult == null && parts[1].equals("length"))
                            {
                                result = new PlainVariableTransformation(result.getOwner(), new NodeToken("vt_dummy"));
                                result.setType(new TypeTransformation(new NodeToken("int")));
                            }
                            else
                                result = newResult;
                        }
                    }
                    
                    name = name.substring(name.indexOf(".") + 1);
                    if (result == null)
                        System.err.println("Result is null: " + name);
                }
                
                MethodTransformation method = (MethodTransformation) getOwner();
                TypeTransformation resultType = result.getType();
                String dummyType = resultType.transform();
                if (dummyType.contains(".Array"))
                    dummyType = "Array";
                NodeToken alias = method.addDummyVariable(dummyType);
                setAlias(alias);
                
                String preTransformation = alias_ + " := " + getCompleteName() + ";";
                addPreTranslationToContainer(preTransformation);
            }
            catch (Exception e)
            {
                QEDVisitor.writeErrorLog("Cannot decode pre translation for access transformation transformation: " + this + ", "
                        + getPositionInTheCode());
                e.printStackTrace();
            }
        }
    }
    
    /**
     * This is a debug method that prints all accesses that are failed to link (initialize) as variable, method and annotation.
     */
    public static void printReport()
    {
        System.out.println("=======================================================================");
        System.out.println("Variable access report");
        
        int variable = 0;
        int method = 0;
        int annotation = 0;
        
        ArrayList<VariableAccessTransformation> variableErrors = new ArrayList<VariableAccessTransformation>();
        ArrayList<VariableAccessTransformation> variableChecks = new ArrayList<VariableAccessTransformation>();
        ArrayList<VariableAccessTransformation> methodErrors = new ArrayList<VariableAccessTransformation>();
        
        for (VariableAccessTransformation vt : accesses_)
        {
            if (vt.accessType_ == AccessType.ANNOTATION)
                annotation++;
            else if (vt.accessType_ == AccessType.METHOD)
            {
                method++;
                if (vt.method_ == null)
                    methodErrors.add(vt);
            }
            else if (vt.accessType_ == AccessType.VARIABLE)
            {
                variable++;
                if (vt.variable_ == null)
                    variableErrors.add(vt);
                else
                    variableChecks.add(vt);
            }
        }
        
        // TODO: Double check these tests one by one with hand!
        
        System.out.println("Reported " + variable + " variable accesses, " + method + " method accesses, and " + annotation
                + " annotation accesses");
        System.out.println("Got " + variableErrors.size() + " variable access errors, and " + methodErrors.size()
                + " method access errors.");
        System.out.println("Variable access errors:");
        for (VariableAccessTransformation vt : variableErrors)
            System.out.println(vt + " " + vt.getPositionInTheCode() + "\nLooked for: " + vt.lookFor_);
        System.out.println("Method access errors:");
        for (VariableAccessTransformation vt : methodErrors)
            System.out.println(vt + " " + vt.getPositionInTheCode());
        
        for (VariableAccessTransformation vt : variableChecks)
            System.out.println(vt);
        
        System.out.println("=======================================================================");
    }
}
