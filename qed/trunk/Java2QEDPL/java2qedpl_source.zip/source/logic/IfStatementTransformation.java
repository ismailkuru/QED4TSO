package logic;

/**
 * {@link IfStatementTransformation} represents 'if ... else' in Java. <br>
 * It has three elements: condition represents the condition of the if, ifPart represents the statements to be executed if the
 * condition is {@code true}, and elsePart represents the statements to be executed if the condition is {@code false}. <br>
 * Else part is (as expected) optional (i.e., can be {@code null}).
 * 
 * @author Kivanc Muslu
 */
public class IfStatementTransformation extends StatementTransformation
{
    private final TransformationExpressionList<StatementTransformation> ifPart_;
    private final TransformationExpressionList<StatementTransformation> elsePart_;
    
    /**
     * Passes the owner container, and condition to {@link StatementTransformation}. <br>
     * Sets the container of ifPart and elsePart as {@code this}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param condition Condition of the if statement.
     * @param ifPart Statements to be executed if the condition is {@code true}.
     * @param elsePart Statements to be executed if the condition is {@code false}.
     */
    protected IfStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> condition,
            TransformationExpressionList<StatementTransformation> ifPart,
            TransformationExpressionList<StatementTransformation> elsePart)
    {
        super(owner, null, condition);
        
        condition.setContainer(this);
        ifPart_ = ifPart;
        elsePart_ = elsePart;
        
        if (ifPart != null)
            ifPart.setContainer(this);
        if (elsePart != null)
            elsePart.setContainer(this);
    }
    
    /**
     * Translation is done almost the same as the Java code. <br>
     * Only the extra brackets (if not there) added after if and else part. <br>
     * Notice that it is each individual element's responsibility to add a pre-translation to this translation in case it is
     * needed. <br>
     * <br>
     * 
     * <strong>Example Translation:</strong> <br>
     * 
     * <pre>
     * if (this.tail == null)
     *     this.tail = updateTail();
     * 
     * ==> is translated to
     * 
     * var dummy: boolean;              // Pre-translation coming from condition.
     * var dummy2: Node;                // Pre-translation coming from ifPart.
     * dummy := this.tail == null;      // Pre-translation coming from condition.
     * if (dummy)
     * {
     *          call dummy2 := updateTail();    // Pre-translation coming from ifPart.
     *          this.tail := dummy2;
     * }
     * </pre>
     * 
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        String conditionTransformation = getAssignedTo().transformCompletely();
        result += "if(" + conditionTransformation + ")\n";
        result += "{\n";
        String ifTransformation = ifPart_.transformCompletely();
        for (String line : ifTransformation.split("\n"))
            result += "\t" + line + "\n";
        result += "}\n";
        if (elsePart_ != null)
        {
            result += "else\n";
            result += "{\n";
            String elseTransformation = elsePart_.transformCompletely();
            for (String line : elseTransformation.split("\n"))
                result += "\t" + line + "\n";
            result += "}\n";
        }
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.IfTransformation: indentation = " + getIndentationLevel();
    }
    
}
