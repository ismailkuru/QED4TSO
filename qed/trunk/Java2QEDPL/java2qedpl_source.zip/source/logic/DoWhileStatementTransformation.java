package logic;

/**
 * {@link DoWhileStatementTransformation} represents 'do ... while' statements in Java. <br>
 * It has two elements: condition represents the condition of the while block and body represents the statements executed in each iteration. <br>
 * This translation is implemented as a syntactic sugar of {@link WhileStatementTransformation}.
 * 
 * @see WhileStatementTransformation#transform()
 * 
 * @author Kivanc Muslu
 */
public class DoWhileStatementTransformation extends WhileStatementTransformation
{
    /**
     * Passes the owner container, condition and body to {@link WhileStatementTransformation}.
     * 
     * @param owner Owner container of this expression.
     * @param condition Condition of the while statement.
     * @param body Body of the while statement.
     */
    protected DoWhileStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> condition,
            TransformationExpressionList<StatementTransformation> body)
    {
        super(owner, condition, body);
    }
    
    /**
     * Translation of {@link DoWhileStatementTransformation} is done as following: <br>
     * <ul>
     * <li> Translate the body of the while statement (since do while extends while). </li>
     * <li> Translate the while statement. </li>
     * </ul>
     * 
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        String temp = transformBody();
        for (String part: temp.split("\n"))
        {
            if (part.startsWith("\t"))
                result += part.substring(1) + "\n" ;
        }
        result += super.transform();
        
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.DoWhileStatementTransformation]";
    }
}
