package logic;

import logic.event.UpdateEvent;
import logic.event.UpdateListener;

/**
 * {@link AssignmentAsExpressionTransformation} represents the assignments that are used as expressions in Java. These are
 * especially seen frequently in if clauses.<br>
 * It has two elements: lhs represents the left hand side of the assignment, assignment represents the assignment. <br>
 * 
 * @author Kivanc Muslu
 */
public class AssignmentAsExpressionTransformation extends AssignmentTransformation implements UpdateEvent
{
    /**
     * Passes the owner container, left hand side and assignment to {@link AssignmentTransformation}. <br>
     * This transformation is added to the container method as an event (since the assignment part must be executed before the actual translation).
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param lhs Left hand side of the assignment.
     * @param assignment Right hand side of the assignment.
     */
    public AssignmentAsExpressionTransformation(ContainerTransformation owner, TransformationExpression lhs,
            TransformationExpressionList<TransformationExpression> assignment)
    {
        super(owner, lhs, assignment);
        
        UpdateListener method = (UpdateListener) owner;
        method.addUpdateEvent(this);
    }
    
    /**
     * Since the assignment part of the translation is already done to the variable declared as 'lhs', translation only returns
     * the translation of the left hand side. <br>
     * <br>
     * <strong>Example translation:</strong>
     * 
     * <pre>
     * number2 = (number1 = 3) + 2
     * </pre>
     * 
     * ==> is translated to
     * 
     * <pre>
     * number1 := 3; // Translated beforehand of the actual translation.
     * number2 := number1 + 2;
     * </pre>
     * 
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        return transformLHS();
    }
    
    /**
     * Assignment part of this translation must be done before hand of the actual translation. <br>
     * So, the assignment part is translated and added to the container of this translation as a pre initialization. <br>
     * <br> {@inheritDoc}
     */
    public void doEvent()
    {
        String preTransformation = "";
        preTransformation = transformPreTransformation();
        clearPreTransformation();
        
        preTransformation += super.transform() + ";";
        addPreInitializationToContainer(preTransformation);
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.AssignmentAsExpressionTransformation]";
    }
    
}
