package logic;

import syntaxtree.NodeToken;
import logic.event.UpdateEvent;
import logic.event.UpdateListener;

/**
 * {@link ArrayInitializationTransformation} represents the translation of array initialization in Java. <br>
 * It has one element: the dimension of the array. <br>
 * <strong>Note: </strong> Array initialization is only implemented for one dimensional arrays. Arrays with more than one
 * dimension cannot be handled with this class.
 * 
 * @author Kivanc Muslu
 */
public class ArrayInitializationTransformation extends TransformationExpression implements UpdateEvent
{
    private TransformationExpressionList<TransformationExpression> sizeTransformation_;
    
    private NodeToken aliasToken_;
    private String alias_;
    
    /**
     * Passes the owner container to {@link TransformationExpression}, assigns {@code this} as the container of
     * sizeTransformation. <br>
     * This transformation is added to the container method as an event (since the whole translation or index transformation must
     * be translated to a dummy variable before the actual transformation).
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param sizeTransformation {@link TransformationExpressionList} which represents (after the translation) the size of the
     *        array.
     */
    protected ArrayInitializationTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> sizeTransformation)
    {
        super(owner);
        sizeTransformation_ = sizeTransformation;
        
        sizeTransformation.setContainer(this);
        
        UpdateListener method = (UpdateListener) owner;
        method.addUpdateEvent(this);
    }
    
    /**
     * Return type of the {@link ArrayInitializationTransformation} is defined as 'Array'. <br>
     * <br> {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return new TypeTransformation(new NodeToken("Array"));
    }
    
    /**
     * Sets the alias.
     * 
     * @param alias Alias that will be used as the result of this translation.
     */
    private void setAlias(NodeToken alias)
    {
        aliasToken_ = alias;
        alias_ = aliasToken_.tokenImage;
    }
    
    /**
     * Transformation of the {@link ArrayAccessTransformation} is done with the following steps: <br>
     * <ul>
     * <li>Return the alias (since all the translation is done and passed to the container).</li>
     * </ul>
     * <strong>Example Translation:</strong><br>
     * <pre>
     * assume that in prelude this is given: ===
     * record Array {
     *          elements: <T> [int]T;
     *          length: int;
     * }
     * 
     * int [] value = new int [100]; ==> is translated as:
     * 
     * var dummy: Array;
     * var value: Array;
     * dummy := New Array;
     * dummy.length := 100;
     * value := dummy;
     * </pre>
     * 
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        return alias_;
    }
    
    /**
     * Returns the complete translation of the array initialization expressions.
     * 
     * @return The complete translation of the array initialization expressions.
     * @see #transform()
     */
    private String realTransformation()
    {
        String result = "";
        String size = sizeTransformation_.transformCompletely();
        result += alias_ + " := New Array;\n";
        result += alias_ + ".length := " + size;
        return result;
    }
    
    /**
     * Since we cannot know to which variable this array will be assigned later on (by just looking to this transformation), I
     * translate this to a dummy variable and return the dummy variable as the result of the translation. <br>
     * This way the the whole translation is translated to a dummy variable. <br>
     * Not to do this, one must look at the related {@link AssignmentTransformation} and get the variable which this translation
     * is assigned to. This is not implemented yet. <br>
     * <br>
     * So, this method gets a dummy variable (Array), from the method that this translation is declared in, creates and passed the
     * whole translation to the container of this translation and sets the alias member.
     * <br>
     * <br> {@inheritDoc}
     */
    public void doEvent()
    {
        MethodTransformation method = (MethodTransformation) getOwner();
        
        NodeToken alias = method.addDummyVariable("Array");
        setAlias(alias);
        
        String preTransformation = realTransformation();
        addPreTranslationToContainer(preTransformation);
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ArrayInitializationTransformation: size = " + sizeTransformation_ + "]";
    }
}
