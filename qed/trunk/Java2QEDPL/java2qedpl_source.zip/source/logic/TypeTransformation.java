package logic;

import syntaxtree.NodeToken;

/**
 * {@link TypeTransformation} represents all types (primitive or reference) in Java. <br>
 * It has one elements: name represents the type. <br>
 * Since they are translated directly (with no addition or extra work), they don't need a container.
 * 
 * @author Kivanc Muslu
 */
public class TypeTransformation extends TransformationExpression
{
    public static final String [] DOUBLE_CLASS = {"double", "float", "long", "int", "short", "byte"};
    public static final String [] FLOAT_CLASS = {"float", "long", "int", "short", "byte"};
    public static final String [] LONG_CLASS = {"long", "int", "short", "byte"};
    public static final String [] INT_CLASS = {"int", "short", "byte"};
    public static final String [] SHORT_CLASS = {"short", "byte"};
    public static final String [] BYTE_CLASS = {"byte"};
    public static final String [] ANY_TYPE = {};
    
    public static final TypeTransformation MIXED_TYPE = new TypeTransformation("mixed");
    public static final TypeTransformation NONE_TYPE = new TypeTransformation("none");
    public static final TypeTransformation TYPELESS = new TypeTransformation("typeless");
    
    /**
     * Passes the name to {@link TransformationExpression}. <br>
     * 
     * @param name String that represents this {@code Literal}.
     */
    protected TypeTransformation(NodeToken name)
    {
        super(null, name, false);
        if (name != null)
        {
            String n = name.tokenImage;
            if (n.equals("boolean"))
                updateName("bool");
        }
    }
    
    /**
     * Passes the name to {@link TransformationExpression}. <br>
     * Only to be called to create the constant TypeTransformation members.
     * 
     * @param name String that represents this {@code Literal}.
     */
    private TypeTransformation(String name)
    {
        this(new NodeToken(name));
    }
    
    /**
     * Return type of TypeTransformation is defined to be itself. <br>
     * <br> {@inheritDoc}
     */
    public TypeTransformation getType()
    {
        return this;
    }
    
    /**
     * Translation just returns the name. <br>
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String name = getName();
        return name;
    }
    
    /**
     * There is never need to indent TypeTransformation. Thus transforWithIndentation is overridden to return the non indented translation. <br>
     * <br>
     * {@inheritDoc}
     */
    public String transformWithIndentation()
    {
        return transformCompletely();
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.TypeTransformation: name = " + getName() + "]";
    }
    
    /**
     * {@inheritDoc}
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof TypeTransformation)
            return equals((TypeTransformation) obj);
        return false;
    }
    
    /**
     * Returns other.getName().equals(getName())
     * @param other Second TypeTransformation to be compared with {@code this}.
     * @return other.getName().equals(getName())
     */
    public boolean equals(TypeTransformation other)
    {
        return getName().equals(other.getName());
    }
    
    /**
     * Returns {@code true} if one of the types (s1 or s2) is exactly type1 and the other type is an element of 'type2' class, {@code false} otherwise.
     * @param s1 Type1 to be checked.
     * @param s2 Type2 to be checked.
     * @param type1 Type to check.
     * @param type2 Type-class to check.
     * @return {@code true} if one of the types (s1 or s2) is exactly type1 and the other type is an element of 'type2' class, {@code false} otherwise
     * @see #matchType(String, String...)
     * @see #combineTwoTypes(TypeTransformation, TypeTransformation)
     */
    private static boolean matchDoubleType(String s1, String s2, String type1, String ... type2)
    {
        return (s1.equals(type1) && matchType(s2, type2)) || (matchType(s1, type2) && s2.equals(type1)); 
    }
    
    /**
     * Returns {@code true} is the 'type' is an element of the 'possibleTypes' class, {@code false} otherwise.
     * @param type Type to be checked.
     * @param possibleTypes A type class such as declared in TypeTransformation.
     * @return {@code true} is the 'type' is an element of the 'possibleTypes' class, {@code false} otherwise.
     * @see #DOUBLE_CLASS
     * @see #INT_CLASS
     * @see #FLOAT_CLASS
     * @see #LONG_CLASS
     * @see #BYTE_CLASS
     */
    private static boolean matchType(String type, String ... possibleTypes)
    {
        if (possibleTypes == ANY_TYPE)
            return true;
        
        for (String s: possibleTypes)
        {
            if (possibleTypes.equals(s))
                return true;
        }
        return false;
    }
    
    /**
     * A tricky method that simulates the type casting in Java, to determine the output of two types when they are not same.
     * @param type1 First type
     * @param type2 Second type
     * @return The resulting type when these types are used in an expression.
     * @see #matchDoubleType(String, String, String, String...)
     */
    protected static TypeTransformation combineTwoTypes(TypeTransformation type1, TypeTransformation type2)
    {
        if (type1.equals(NONE_TYPE))
            return type2;
        if (type2.equals(NONE_TYPE))
            return type1;
        
        String name1 = type1.getName();
        String name2 = type2.getName();
        String name = "";
        
        if (name1.equals(name2))
            name = name1;
        else if (matchDoubleType(name1, name2, "double", DOUBLE_CLASS))
            name = "double";
        else if (matchDoubleType(name1, name2, "float", FLOAT_CLASS))
            name = "float";
        else if (matchDoubleType(name1, name2, "long", LONG_CLASS))
            name = "long";
        else if (matchDoubleType(name1, name2, "int", INT_CLASS))
            name = "int";
        else if (matchDoubleType(name1, name2, "short", SHORT_CLASS))
            name = "short";
        else if (matchDoubleType(name1, name2, "byte", BYTE_CLASS))
            name = "byte";
        else if (matchDoubleType(name1, name2, "String", ANY_TYPE))
            name = "double";

        if (type1.equals(MIXED_TYPE) || type2.equals(MIXED_TYPE))
            return MIXED_TYPE;
        
        if (name.equals(""))
            return MIXED_TYPE;
        
        return new TypeTransformation(new NodeToken(name));
    }
}
