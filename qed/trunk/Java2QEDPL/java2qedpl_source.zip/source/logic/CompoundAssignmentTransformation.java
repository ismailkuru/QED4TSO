package logic;

import syntaxtree.NodeToken;

/**
 * {@link CompoundAssignmentTransformation} represents the compound assignments in Java (e.g., +=, -=, *= T). <br>
 * It has three elements: lhs represents the left hand side of the assignment, assignment represents the assignment and the
 * operator represents the operator. <br>
 * 
 * @author Kivanc Muslu
 */
public class CompoundAssignmentTransformation extends AssignmentTransformation
{
    private final NodeToken operatorToken_;
    private final String operator_;
    
    /**
     * Passes the owner container, left hand side and assignment to {@link AssignmentTransformation}.
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param lhs Left hand side of the assignment.
     * @param operator Operator that is used in the assignment.
     * @param assignment Right hand side of the assignment.
     */
    public CompoundAssignmentTransformation(ContainerTransformation owner, TransformationExpression lhs, NodeToken operator,
            TransformationExpressionList<TransformationExpression> assignment)
    {
        super(owner, lhs, assignment);
        operatorToken_ = operator;
        operator_ = operatorToken_.tokenImage;
    }
    
    /**
     * Compound expressions are normally a syntactic sugar to the following: <br>
     * 'lhs' 'operator'= 'rhs' <==> 'lhs' = 'lhs' 'operator' 'rhs' <br>
     * <br>
     * <strong>Example Translation:</strong> <br>
     * 
     * <pre>
     * number += 3;
     * </pre>
     * 
     * ==> is translated to
     * 
     * <pre>
     * number := number + 3;
     * </pre>
     * 
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String lhs = transformLHS();
        String rhs = transformRHS();
        String result = lhs + " := " + lhs + " " + operator_ + " (" + rhs + ")";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.CompoundAssignmentTransformation: operator = " + operator_ + ", indentation = " + getIndentationLevel()
                + "]";
    }
    
}
