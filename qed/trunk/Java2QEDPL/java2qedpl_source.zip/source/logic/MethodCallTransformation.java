package logic;

import syntaxtree.NodeToken;
import logic.event.UpdateEvent;
import logic.event.UpdateListener;

/**
 * {@link MethodCallTransformation} represents method calls in Java. <br>
 * It has two elements: name represents the method name, arguments represent the arguments that are passed to the method call. <br>
 * noArgs is actually derived (it is arguments.size()).
 * 
 * @author Kivanc Muslu
 */
public class MethodCallTransformation extends TransformationExpression implements UpdateEvent
{
    private final VariableAccessTransformation methodName_;
    private final TransformationExpressionList<TransformationExpression> arguments_;
    private final int noArgs_;
    
    private NodeToken alias_;
    private String aliasName_;
    
    /**
     * Passes the owner container to {@link StatementTransformation}. <br>
     * Sets the container of arguments as {@code this}. <br>
     * This transformation is added to the container method as an event (since the method calls inside expressions must be
     * executed before the actual translation).
     * 
     * @param owner Owner container of this expression.
     * @param name Method name (as a {@link VariableAccessTransformation}).
     * @param arguments Arguments that are passed to method call.
     * @param noArgs Number of arguments passed to method call (basically = arguments.size()).
     */
    protected MethodCallTransformation(ContainerTransformation owner, TransformationExpression name,
            TransformationExpressionList<TransformationExpression> arguments, int noArgs)
    {
        super(owner, null, true);
        
        methodName_ = (VariableAccessTransformation) name;
        methodName_.makeMehodAccess();
        methodName_.setNoArgs(noArgs);
        
        arguments_ = arguments;
        noArgs_ = noArgs;
        
        arguments.setContainer(this);
        
        UpdateListener listener = (UpdateListener) owner;
        listener.addUpdateEvent(this);
    }
    
    /**
     * Return type of the method call is the same as the method name's return type (since it is a
     * {@link VariableAccessTransformation}). <br>
     * <br>{@inheritDoc}
     */
    public TypeTransformation getType()
    {
        return methodName_.getType();
    }
    
    /**
     * Decides what should be passed to QED PL procedure call (Java method call) as the first argument. <br>
     * This is required since QED PL is not Object Oriented. To simulate OOP, one must pass an instance of {@code this} as the
     * first argument to all class functions (to access class variables and methods later on). <br>
     * <br>
     * Basic procedure is as follows: <br>
     * <ul>
     * <li>Figure out and update the complete method name. (i.e., all class non-static methods have 'class_name' as prefix to
     * their method names).</li>
     * <li>Try to retrieve the actual {@link MethodTransformation} (method) from the method name. If method doesn't exists (i.e.,
     * null) return empty string (since there is no parameter). The same is also valid is the method is static.</li>
     * <li>If there really is a need for first parameter, then look at the original method call name. If it has a '.' in it (e.g.,
     * s.prev()), then pass the first string before the '.' (e.g., 's' in the prev. example).</li>
     * <li>If there is not dot, then assign 'this' as the first parameter.</li>
     * </ul>
     * 
     * @return The first parameter that should be passed to the QED PL procedure call (in the translation).
     * @see VariableAccessTransformation#updateMethodAccessName(int)
     * @see VariableAccessTransformation#getOriginalName()
     * @see VariableAccessTransformation#getMethod()
     * 
     */
    public String findFirstParameter()
    {
        methodName_.updateMethodAccessName(noArgs_);
        String name = methodName_.getOriginalName();
        
        MethodTransformation method = methodName_.getMethod();
        if (method != null && method.isStatic())
            return "";
        if (name.contains("."))
            return name.split("\\.")[0];
        else
            return "this";
    }
    
    /**
     * Since the actual translation of the method call is already passed to the container, only the alias is returned as the
     * translation. <br>
     * <br>
     * <strong>Example Translation:</strong> <br>
     * 
     * <pre>
     * int a = someClass.someMethod(arg1); // assume that someMethod returns int.
     * 
     * ==&gt; is translated to
     * 
     * var a: int;
     * var dummy: int;
     * 
     * call dummy := SomeClass_someMethod(someClass, arg1); // pre translation.
     * a := dummy; // actual translation.
     * </pre>
     * 
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        return aliasName_;
    }
    
    /**
     * Sets the alias.
     * 
     * @param alias Alias that represents the translation.
     */
    private void setAlias(NodeToken alias)
    {
        alias_ = alias;
        aliasName_ = alias_.tokenImage;
    }
    
    /**
     * The real translation that is passed to container as a pre-translation.
     * 
     * @return String representation of the real translation.
     * @see #transform()
     */
    private String realTransformation()
    {
        String result = "";
        String firstParameter = findFirstParameter();
        result += methodName_.transformCompletely() + "(" + firstParameter;
        if (arguments_.getSize() != 0)
        {
            String args = "";
            for (TransformationExpression te : arguments_.getList())
                args += ", " + te.transformCompletely();
            
            if (firstParameter.equals(""))
                args = args.substring(2, args.length());
            
            result += args;
        }
        result += ")";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        String result = "[logic.MethodCallTransformation: name = " + methodName_.transformCompletely() + ", indentation = "
                + getIndentationLevel() + "]";
        return result;
    }
    
    /**
     * Passes the actual translation to the container. Done with the following steps: <br>
     * <ul>
     * <li> Figure out the method call return type and if it is not 'void', take a dummy variable with the same type from the method this translation declared in. </li>
     * <li> Translate this method call to the dummy variable and add this as a pre-translation to the container. </li>
     * <li> Set the alias as the dummy variable </li>
     * </ul>
     * <br>{@inheritDoc}
     * @see VariableAccessTransformation#getMethodReturnType()
     */
    public void doEvent()
    {
        TypeTransformation returnType = methodName_.getMethodReturnType();
        NodeToken varName = null;
        String preTranslataion = "";
        preTranslataion += transformPreTransformation();
        clearPreTransformation();
        if (returnType == null)
        {
            QEDVisitor.writeErrorLog("Cannot determine return type for method: " + methodName_);
            varName = new NodeToken("unknown");
        }
        else if (returnType.transform().equals("void"))
        {
            varName = new NodeToken("");
            setAlias(varName);
            preTranslataion += "call " + realTransformation() + ";";
        }
        else
        {
            varName = getOwner().addDummyVariable(returnType.transformCompletely());
            setAlias(varName);
            preTranslataion += "call " + aliasName_ + " := " + realTransformation() + ";";
        }
        
        addPreTranslationToContainer(preTranslataion);
    }
    
}
