package logic;

import syntaxtree.NodeToken;

/**
 * {@link PlainVariableTransformation} represents non-static variable declarations without assignment in Java. <br>
 * It has one element: variableName which represents the name of the variable.<br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC.
 * 
 * @author Kivanc Muslu
 */
public class PlainVariableTransformation extends VariableTransformation
{
    /**
     * Passes the owner container and variableName to {@link VariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     */
    protected PlainVariableTransformation(ContainerTransformation owner, NodeToken variableName)
    {
        super(owner, variableName);
    }
    
    /**
     * Not to be called by QEDVisitor. This constructor is only called by {@link VariableWithAssignmentTransformation} for
     * inheritance. <br>
     * Passes the owner container, variableName and assignment to {@link VariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected PlainVariableTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
    }
    
    /**
     * <strong>Example Translation:</strong> <br>
     * 
     * <pre>
     * int counter;
     * 
     * ==&gt; is translated to 
     * 
     * var counter: int;
     * 
     * </pre> {@inheritDoc}
     */
    public String transform()
    {
        if (isOnlyAssignmentTransformation())
            return "";
        
        Aux.printDebugTraversal(this);
        String result = "";
        result += "var " + getName() + ": " + getTypeName() + ";\n";
        return result;
    }
    
    /**
     * Since this is a plain variable, it shouldn't have an assignment and a request to translate assignment returns empty string. <br>
     * <br> {@inheritDoc}
     */
    public String transformAssignment()
    {
        return "";
    }
    
    /**
     * Overridden to create a new instance of the same translation. Because declaration can be modified and we don't want the
     * actual variable to be modified at the same time. <br>
     * <br>{@inheritDoc}
     */
    public VariableTransformation getDeclaration()
    {
        VariableTransformation result = new PlainVariableTransformation(getOwner(), getNameToken());
        result.setType(getType());
        
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.PlainVariableTransformation: name = " + getName() + ", type = " + getType() + ", indentation = "
                + getIndentationLevel() + "]";
    }
}
