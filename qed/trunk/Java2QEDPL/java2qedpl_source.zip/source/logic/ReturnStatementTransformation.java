package logic;

import logic.annotation.JAVA2QEDPL;

/**
 * {@link ReturnStatementTransformation} represents 'return' statements in Java. <br>
 * It has one element: a list representing what to return. Note: can be empty list (i.e., just return).<br>
 * 
 * @author Kivanc Muslu
 */
public class ReturnStatementTransformation extends StatementTransformation
{
    
    /**
     * Passes the owner container and return list (as assignedTo) to {@link StatementTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param returnList List that represents what to return.
     */
    protected ReturnStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> returnList)
    {
        super(owner, null, returnList);
    }
    
    /**
     * <strong>Example Translation:</strong>
     * 
     * <pre>
     * return 3;
     * 
     * ==&gt; is translated to
     * 
     * functionResult := 3; // For now result of the function is named as 'functionResult' in QED PL translations.
     * return;
     *</pre>
     * 
     * {@inheritDoc}
     * @see JAVA2QEDPL#RESULT
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        if (getAssignedTo().getSize() != 0)
            result += MethodTransformation.RESULT_NAME + " := " + getAssignedTo().transformCompletely() + ";\n";
        result += "return;\n";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ReturnStatementTransformation: indentation = " + getIndentationLevel() + "]";
    }
    
}
