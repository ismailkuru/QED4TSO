 package logic;

import java.util.ArrayList;

import syntaxtree.NodeToken;

/**
 * {@link ConstructorTransformation} represents the constructors in Java. <br>
 * It has two elements: name representing the constructor name, and visibility representing the visibility (public, private,
 * package, protected) <br>
 * 
 * @author Kivanc Muslu
 */
public class ConstructorTransformation extends MethodTransformation
{
    /**
     * This List represents the assignments that are added by the non-static field declarations (assignments).
     * @see ClassTransformation#transform()
     */
    private final ArrayList<VariableTransformation> topLevelAssignments_;
    
    /**
     * Passes the owner container, name and visibility {@link MethodTransformation}.
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param name Name of the constructor (expected to be the same as the class name).
     * @param visibility Visibility of the constructor.
     */
    public ConstructorTransformation(ContainerTransformation owner, NodeToken name, String visibility)
    {
        super(owner, name, visibility, false);
        topLevelAssignments_ = new ArrayList<VariableTransformation>();
    }

    /**
     * Adds top level assignment to the constructor.
     * @param vt {@link VariableTransformation} that represents the assignment (of the variable).
     * @see #topLevelAssignments_
     */
    protected void addTopLevelAssignment(VariableTransformation vt)
    {
        topLevelAssignments_.add(vt);
    }
    
    /**
     * Constructs and returns the translation where the top level assignments are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the top level assignments).
     * @see #addTopLevelAssignment(VariableTransformation)
     */
    private String addTopLevelAssignmentsToCurrentTransformation(String current)
    {
        String result = current;
        for (VariableTransformation vd : topLevelAssignments_)
            result += Aux.appendBeginning(vd.transformAssignmentWithIndentation(), "this.");
        if (!result.equals(current))
            result += "\n";
        return result;
    }
    
    /**
     * In addition to any method translation, constructor translation also adds a call to the first 'dummy' constructor and adds the top-level translations. <br> 
     * <br>{@inheritDoc}
     * @see #addTopLevelAssignment(VariableTransformation)
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        broadcast();
        String result = "";
        result += transformPart1();
        if (isOverridden())
        {
            String name = getOriginalCompleteName();
            result += "\tcall " + name + "(this);\n";
        }
        else
            result = addTopLevelAssignmentsToCurrentTransformation(result);
        result += transformPart2();
        
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ConstructorTransformation: name = " + getCompleteName() + ", indentation level = " + getIndentationLevel()
                + "]";
    }
}
