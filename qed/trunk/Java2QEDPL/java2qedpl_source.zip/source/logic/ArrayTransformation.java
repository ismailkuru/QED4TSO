package logic;

import syntaxtree.NodeToken;

/**
 * {@link ArrayTransformation} represents the declaration of array initialization in Java. <br>
 * It has three elements: variableName represents the name of the array, assignedTo represents the assignment (if any), and
 * arrayDimension represents the dimension of the array (which is not used at the moment) <br>
 * <strong>Note: </strong> Array declaration is only implemented for one dimensional arrays. Arrays with more than one
 * dimension cannot be handled with this class.
 * 
 * @author Kivanc Muslu
 */
public class ArrayTransformation extends VariableTransformation
{
    @SuppressWarnings("unused")
    private final int arrayDimension_;
    
    /**
     * Passes the owner container, variable name and assignment to {@link VariableTransformation}.
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param variableName Name of the array.
     * @param assignedTo Assignment of the array.
     * @param arrayDimension Dimension of the array.
     */
    protected ArrayTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo, int arrayDimension)
    {
        super(owner, variableName, assignedTo);
        arrayDimension_ = arrayDimension;
    }
    
    /**
     * Array declaration type is defined as "element_type".Array. This is done to have access to the element type of the array
     * later on. <br>
     * <br>{@inheritDoc}
     */
    public TypeTransformation getType()
    {
        TypeTransformation type = super.getType();
        TypeTransformation result = new TypeTransformation(new NodeToken(type.getName() + ".Array"));
        return result;
    }
    
    /**
     * Returns the translation of the assignment part (if any) of the array declaration. 
     * <br>
     * <br>{@inheritDoc}
     */
    public String transformAssignment()
    {
        if (getAssignedTo() != null)
        {
            String result = getName() + " := New Array;\n";
            result += getName() + ".length := " + getAssignedTo().transformCompletely();
            return result;
        }
        else
            return "";
    }
    
    /**
     * <strong>Example translation:</strong>
     * <pre>
     * int [] numbers;
     * </pre>
     * ==> is translated to
     * <pre>
     * var numbers: Array;
     * </pre>
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result = "var " + getName() + ": Array; ";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ArrayTransformation: name = " + getName() + "]";
    }
    
}
