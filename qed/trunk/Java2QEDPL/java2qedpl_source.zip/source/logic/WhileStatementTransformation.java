package logic;

/**
 * {@link WhileStatementTransformation} represents 'while' statements in Java. <br>
 * It has two elements: condition represents the condition of the while block and body represents the statements executed in each iteration. <br>
 * 
 * @see WhileStatementTransformation#transform()
 * 
 * @author Kivanc Muslu
 */
public class WhileStatementTransformation extends StatementTransformation
{
    private final TransformationExpressionList<StatementTransformation> body_;
    
    /**
     * Passes the owner container and condition to {@link StatementTransformation} and sets the container of body and condition as {@code this}.
     * 
     * @param owner Owner container of this expression.
     * @param condition Condition of the while statement.
     * @param body Body of the while statement.
     */
    protected WhileStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> condition,
            TransformationExpressionList<StatementTransformation> body)
    {
        super(owner, null, condition);
        body_ = body;
        
        body.setContainer(this);
        condition.setContainer(this);
    }
    
    /**
     * Translates the first part of the while statement which is the condition and the body iterations.
     * @return The translation of the first part of the while statement.
     */
    protected String transformUntilTheEnd()
    {
        String result = "";
        String conditionTransformation = "";
        if (getCondition() == null)
            conditionTransformation = "true";
        else
            conditionTransformation = getCondition().transformCompletely();
        if (conditionTransformation.equals(""))
            conditionTransformation = "true";
        
        result += "while(" + conditionTransformation + ")\n";
        result += "{\n";
        result += transformBody();
        
        return result;
    }
    
    /**
     * Translates and returns the body iterations of while statement. This is done separately so that DoWhileStatementTransformation can be implemented easily.
     * @return The translation of the body iterations of while statement.
     * @see DoWhileStatementTransformation#transform()
     */
    protected String transformBody()
    {
        String result = "";
        for (StatementTransformation statement: body_)
            result += statement.transformWithIndentation();
        
        return result;
    }
    
    /**
     * Returns the condition of while. Implemented so that 'assignedTo' will be more meaningful for WhileStatementTransformation.
     * @return The condition of while.
     */
    private TransformationExpressionList <TransformationExpression> getCondition()
    {
        return getAssignedTo();
    }
    
    /**
     * Returns the transformation after the body iterations. They are just the repetition of the pre-translation and closing the bracket. <br>
     * This is done separately to be able to put the iteration statement of ForStatementTransformation easily.
     * @return The transformation after the body iterations.
     * @see ForStatementTransformation#transform()
     */
    protected String transformTheEnd()
    {
        String result = "";
        String preTransform = transformPreTransformation();
        for (String line: preTransform.split("\n"))
        {
            if (!line.trim().equals(""))
                result += "\t" + line + "\n";
        }

        result += "}\n";
        return result;
    }
    
    /**
     * Transformation is done in two pieces. This is done to implement {@link ForStatementTransformation} and {@link DoWhileStatementTransformation} easier. <br>
     * <br>
     * <strong>Example translation (for WhileStatementTransformation):</strong>
     * <pre>
     * while (tail != null)             // Assume that tail is a global variable.
     *          tail = tail.prev;
     *          
     * ==> is translated to 
     * 
     * var dummy: bool;                 // Pre translation of while (coming from condition ==> expression list ==> while)
     * var dummy2: Node;                // Pre translation of tail.prev.
     * 
     * dummy := this.tail != null;      // Assuming that this represents the instance. Pre-translation of while.
     * while (dummy)
     * {
     *          dummy2 := this.tail.prev;
     *          this.tail := dummy2;
     *          
     *          dummy := this.tail != null;     // Pre translation of while must be executed again at the end of while to be correct.
     * }
     * </pre>
     * 
     * {@inheritDoc}
     * @see #transformUntilTheEnd()
     * @see #transformTheEnd()
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result += transformUntilTheEnd();
        result += transformTheEnd();
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.WhileStatementTransformation]";
    }
    
}
