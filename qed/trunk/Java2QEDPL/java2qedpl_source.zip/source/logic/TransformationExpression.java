package logic;

import java.util.ArrayList;

import syntaxtree.NodeToken;

/**
 * {@link TransformationExpression} is the abstract representation of any expression in Java. <br>
 * It is the super class of all Transformations created and used. One can think it as the {@link Object} translation internal
 * structures. <br>
 * It has three elements: owner represents owner container of {@code this}, name represents name, and indent represents weather
 * the translation should be indented before printing with respect to its container or not.<br>
 * None of these elements are mandatory or guaranteed to be used in translations. I.e., MAIN_CLASS_DECLARATION does not have an
 * owner (i.e., == {@code null}, and only it has this privilege), {@link IfStatementTransformation},
 * {@link WhileStatementTransformation}, and much more does not have a name, and one can always bypass the indentation by calling
 * {@code transform()}, instead of {@code transformWithIndentation()}. <br>
 * <br>
 * <strong>Field Summary:</strong> <br>
 * container_ - Container of this transformation. It is the parent of this transformation in AST. <br>
 * preTransformation_ - The translation that should be written before translation of {@code this}. <br>
 * preInitialiazation_ - The initialization that should be written before the translation of {@code this} and {@code
 * preTransformation_}. <br>
 * 
 * @author Kivanc Muslu
 * @see #transform()
 * @see #transformWithIndentation()
 * @see ClassTransformation#getMainClassTransformation()
 */
public abstract class TransformationExpression
{
    private NodeToken nameToken_;
    private String name_;
    
    private ContainerTransformation owner_;
    private TransformationExpression container_;
    private int indentationLevel_;
    
    private ArrayList<String> preTransformation_ = new ArrayList<String>();
    private ArrayList<String> preInitialization_ = new ArrayList<String>();
    
    /**
     * Sets the owner and name, and increases the indentation with respect to owner, if indent is {@code true}.
     * 
     * @param owner Owner container of this expression.
     * @param name Name of this expression.
     * @param indent Flag that represents weather this expression should be indented with respect to its owner or not during
     *        translation.
     */
    protected TransformationExpression(ContainerTransformation owner, NodeToken name, boolean indent)
    {
        nameToken_ = name;
        if (name != null)
            name_ = nameToken_.tokenImage;
        owner_ = owner;
        if (owner_ != null)
        {
            if (indent)
                indentationLevel_ = owner.getIndentationLevel() + 1;
            else
                indentationLevel_ = owner.getIndentationLevel();
        }
        else
            indentationLevel_ = -1;
    }
    
    /**
     * Sets name, sets owner to {@code null} and indentationLevel_ to {@code -1}. <br>
     * This constructor should NOT be called by {@link QEDVisitor}. This constructor should only be called by
     * {@link ClassTransformation} and for the creation of MAIN_CLASS_DECLARATION.
     * 
     * @param name Name of this expression.
     */
    protected TransformationExpression(String name)
    {
        nameToken_ = null;
        name_ = name;
        owner_ = null;
        indentationLevel_ = -1;
    }
    
    /**
     * Sets owner, sets name to {@code null} and indentationLevel_ to {@code -1}. <br>
     * 
     * @param owner Owner container of this expression.
     */
    protected TransformationExpression(ContainerTransformation owner)
    {
        nameToken_ = null;
        name_ = null;
        owner_ = owner;
        indentationLevel_ = -1;
    }
    
    /**
     * Returns the code position using the nameToken_ field. This token is created by JavaCC during the parsing. <br>
     * This method is used to generate more meaningful error messages when something wrong is detected (during the translation). <br>
     * 
     * @return The code position using the nameToken_ field.
     */
    protected String getPositionInTheCode()
    {
        if (nameToken_ == null)
            return "@(-1, -1)";
        else
            return "@(" + nameToken_.beginLine + ", " + nameToken_.beginColumn + ")";
    }
    
    /**
     * Returns container expression.
     * 
     * @return Container expression.
     */
    protected TransformationExpression getContainer()
    {
        return container_;
    }
    
    /**
     * Sets container expression.
     * 
     * @param container Container expression to be set.
     */
    protected void setContainer(TransformationExpression container)
    {
        container_ = container;
    }
    
    /**
     * Updates the name value.
     * 
     * @param name Name to be set.
     */
    protected void updateName(String name)
    {
        nameToken_.tokenImage = name;
        name_ = name;
    }
    
    /**
     * Returns name.
     * 
     * @return Name.
     */
    public String getName()
    {
        return name_;
    }
    
    /**
     * Returns the name token.
     * 
     * @return The name token.
     */
    public NodeToken getNameToken()
    {
        return nameToken_;
    }
    
    /**
     * Returns owner container.
     * 
     * @return Owner container.
     */
    public ContainerTransformation getOwner()
    {
        return owner_;
    }
    
    /**
     * Returns indentation level.
     * 
     * @return Indentation level.
     */
    protected int getIndentationLevel()
    {
        return indentationLevel_;
    }
    
    /**
     * Returns number of tabs (as a String) that are equal to the indentation level.
     * 
     * @return Number of tabs (as a String) that are equal to the indentation level.
     */
    protected String getIndentedString()
    {
        String result = "";
        for (int a = 0; a < indentationLevel_; a++)
            result += "\t";
        return result;
    }
    
    /**
     * Adds pre-transformation at the end of the list that comes from {@link TransformationExpression} 'te'.
     * 
     * @param transformation Transformation to be added to the list.
     * @param te Transformation expression that created this pre-translation.
     */
    protected void addPreTransformation(String transformation, TransformationExpression te)
    {
        addPreTransformation(transformation);
    }
    
    /**
     * Adds pre-transformation at the end of the list. Pre-transformation is created by {@code this}.
     * 
     * @param transformation Transformation to be added to the list.
     */
    protected void addPreTransformation(String transformation)
    {
        preTransformation_.add(transformation);
    }
    
    /**
     * Adds pre-transformation at the end of the container's pre-transformation list. Pre-transformation is created by {@code
     * this}.
     * 
     * @param transformation Transformation to be added to the list.
     */
    protected void addPreTranslationToContainer(String transformation)
    {
        container_.addPreTransformation(transformation, this);
    }
    
    /**
     * Adds pre-initialization at the end of the container's pre-initialization list. Pre-initialization is created by {@code
     * this}.
     * 
     * @param initialization Initialization to be added to the list.
     */
    protected void addPreInitializationToContainer(String initialization)
    {
        container_.addPreInitialization(initialization);
    }
    
    /**
     * Adds pre-initialization at the end of the list. Pre-initialization is created by {@code this}.
     * 
     * @param initialization Initialization to be added to the list.
     */
    protected void addPreInitialization(String initialization)
    {
        preInitialization_.add(initialization);
    }
    
    /**
     * Returns the pre-transformation list.
     * 
     * @return The pre-transformation list.
     */
    protected ArrayList<String> getPreTransformation()
    {
        return preTransformation_;
    }
    
    /**
     * Removes pre-transformation or pre-initialization that is equal to 'transformation' (if any exists).
     * 
     * @param transformation Transformation to be removed.
     */
    protected void clearPreTransformation(String transformation)
    {
        int index = -1;
        for (int a = 0; a < preTransformation_.size(); a++)
        {
            if (preTransformation_.get(a).equals(transformation))
            {
                index = a;
                break;
            }
        }
        
        if (index != -1)
            preTransformation_.remove(index);
        else
            return;
        
        index = -1;
        
        for (int a = 0; a < preInitialization_.size(); a++)
        {
            if (preInitialization_.get(a).equals(transformation))
            {
                index = a;
                break;
            }
        }
        
        if (index != -1)
            preInitialization_.remove(index);
    }
    
    /**
     * Returns the pre-initialization concatenated to pre-transformation as {@link String}.
     * 
     * @return The pre-initialization concatenated to pre-transformation as String.
     */
    protected String transformPreTransformation()
    {
        String result = "";
        for (String s : preInitialization_)
            result += s + "\n";
        for (String s : preTransformation_)
            result += s + "\n";
        
        return result;
    }
    
    /**
     * Returns the pre-initialization as {@link String}.
     * 
     * @return The pre-initialization as String.
     */
    protected String transformPreInitialization()
    {
        String result = "";
        for (String s : preInitialization_)
            result += s + "\n";
        
        return result;
    }
    
    /**
     * Completely clears the pre-initialization list.
     */
    protected void clearPreInitialization()
    {
        preInitialization_.clear();
    }
    
    /**
     * Completely clears the pre-initialization and pre-transformatio lists.
     */
    protected void clearPreTransformation()
    {
        preTransformation_.clear();
        preInitialization_.clear();
    }
    
    /**
     * Translation method that must be implemented by each concrete translation class. For all translations (complete-translation,
     * indented translation, etc.) this method is used as a base. <br>
     * Complete translation means the translation of pre-initialization + translation of pre-translation + the plain translation
     * (this process). <br>
     * Indented translation means the complete translation that is indented using the indentation level information. <br>
     * 
     * @return Returns the plain translation represented as a String.
     * @see #transformCompletely()
     * @see #transformWithIndentation()
     */
    public abstract String transform();
    
    /**
     * Returns the complete translation (without indentation) using the plain translation.
     * 
     * @return The complete translation (without indentation).
     * @see #transform()
     */
    public String transformCompletely()
    {
        String result = transform();
        if (addPreTransformation())
            result = transformPreTransformation() + result;
        return result;
    }
    
    /**
     * This method represents weather the pre-translation should be included to the complete translation or not. <br>
     * It is by default {@code true}. However sub-classes can override and return {@code false} to prevent the translation of the
     * pre-translation. <br>
     * 
     * @return {@code true} by default.
     */
    protected boolean addPreTransformation()
    {
        return true;
    }
    
    /**
     * For (almost) complete type-checking, all translation objects must have a return type to be implemented by the concrete classes.
     * @return The type of the resulting translation. (If it were to be used in as an expression).
     */
    protected abstract TypeTransformation getType();
    
    /**
     * Returns the complete translation (with indentation) using the complete translation.
     * @return The complete translation (with indentation) using the complete translation.
     */
    public String transformWithIndentation()
    {
        String result = transformCompletely();
        
        String actualResult = "";
        String[] lines = result.split("\n");
        for (String line : lines)
            actualResult += getIndentedString() + line + "\n";
        return actualResult;
    }
}
