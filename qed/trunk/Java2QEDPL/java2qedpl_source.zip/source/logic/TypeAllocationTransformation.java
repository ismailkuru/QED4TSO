package logic;

import syntaxtree.NodeToken;
import logic.event.UpdateEvent;
import logic.event.UpdateListener;

/**
 * {@link TypeAllocationTransformation} represents 'new ...' in Java. <br>
 * It has two elements: type represents the new type to be created and arguments represents the arguments to be passed to the
 * constructor during this process.<br>
 * noArgs is actually a derived member: represents the number of arguments.<br>
 * 
 * @author Kivanc Muslu
 */
public class TypeAllocationTransformation extends TransformationExpression implements UpdateEvent
{
    private TransformationExpressionList<TransformationExpression> arguments_;
    private int noArgs_;
    private TypeTransformation type_;
    
    private NodeToken aliasNode_;
    private String alias_;
    private String constructorName_;
    
    /**
     * 
     * Passes the owner container, and condition to {@link TransformationExpression}. <br>
     * Sets the container of arguments as {@code this}. <br>
     * Adds itself as an event to the method it is declared (since in QED PL the type allocation and constructor call must be in
     * two sentences). <br>
     * Also note that in Java one can call new() on static members since there is Class that represents it, however (for now) this
     * cannot be translated in QED PL (static allocation) </br>
     * So whenever the owner is not a method (a class), this translation is ignored.
     * 
     * @param owner Owner container of this expression.
     * @param type Type of the to be allocated object.
     * @param arguments Arguments that should be passed to the constructor during the allocation.
     * @param noArgs Derived member, number of arguments.
     */
    public TypeAllocationTransformation(ContainerTransformation owner, TypeTransformation type,
            TransformationExpressionList<TransformationExpression> arguments, int noArgs)
    {
        super(owner, null, false);
        arguments_ = arguments;
        noArgs_ = noArgs;
        type_ = type;
        
        arguments_.setContainer(this);
        
        try
        {
            UpdateListener method = (UpdateListener) owner;
            method.addUpdateEvent(this);
        }
        catch (Exception e)
        {}
    }
    
    /**
     * Return type of {@code TypeAllocationTransformation} is defined as the new Type to be allocated. <br>
     * <br> {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return type_;
    }
    
    /**
     * Sets alias.
     * 
     * @param node Alias to be set.
     */
    private void setAlias(NodeToken node)
    {
        aliasNode_ = node;
        alias_ = aliasNode_.tokenImage;
    }
    
    /**
     * Since the actual translation is done as a pre-translation and passed to the container, only the alias is returned. <br>
     * <br>
     * <strong>Example translation (for TypeAllocationTransformation):</strong>
     * 
     * <pre>
     * Counter myCounter = new Counter(count);  // Assuming that Counter class has a constructor that is called with only one argument (int) and count is of type int.
     * 
     * ==&gt; is translated to
     * 
     * var myCounter: Counter;
     * var dummy: Counter;                      // These are all pre-translations.
     * dummy = New Counter;                     // These are all pre-translations.
     * call Counter_Counter(dummy, count);      // These are all pre-translations.
     * 
     * myCounter := dummy;
     * </pre>
     * 
     * {@inheritDoc}
     * 
     * @see #doEvent()
     * @see #realTransformation()
     */
    public String transform()
    {
        return alias_;
    }
    
    /**
     * Returns the actual translation.
     * 
     * @return The actual translation.
     */
    private String realTransformation()
    {
        String result = "";
        result += alias_ + " := New " + type_.transform() + ";\n";
        String args = alias_ + ", ";
        for (TransformationExpression te : arguments_)
            args += te.transformCompletely() + ", ";
        args = args.substring(0, args.length() - 2);
        result += "call " + constructorName_ + "(" + args + ");";
        
        return result;
    }
    
    /**
     * A dummy variable of the type of the allocation is taken from the method that this expression is defined and set as alias. <br>
     * From all methods, the constructor that matches to this allocation is found. Note: This does not work 100% for now. May
     * return the wrong constructor if there are overridden constructors that takes same number of arguments. Requires complete
     * type checking so that the type of the arguments and constructor parameters can also be matched in case there is more than
     * one constructor with same number of arguments. <br>
     * This constructor is called after the allocation with the arguments. <br>
     * 
     * <br>{@inheritDoc}
     * @see MethodTransformation#getCompleteName()
     */
    public void doEvent()
    {
        MethodTransformation method = (MethodTransformation) getOwner();
        String type = type_.transform();
        NodeToken alias = method.addDummyVariable(type);
        setAlias(alias);
        
        TypeTransformation[] types = new TypeTransformation[arguments_.getSize()];
        for (int a = 0; a < types.length; a++)
            types[a] = arguments_.getElementAt(a).getType();
        
        // TODO: This is intended to search for the correct constructor, however since type matching does not work completely this
        // does not work too.
        MethodTransformation constructor = MethodTransformation.getMethodTransformation(type, noArgs_, types);
        constructorName_ = constructor == null ? type : constructor.getCompleteName();
        
        String preTransformation = transformPreTransformation();
        clearPreTransformation();
        preTransformation += realTransformation();
        addPreTranslationToContainer(preTransformation);
    }
}
