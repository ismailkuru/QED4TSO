package logic.event;

import logic.MethodTransformation;
import logic.TransformationExpression;

/**
 * {@link UpdateListener} is currently implemented by all {@link MethodTransformation} since broadcasting the events before the
 * method translation is sufficient at the moment. <br>
 * Any {@link TransformationExpression} can implement this event, if some of its elements must perform some event before the
 * actual translation of the listener.
 * 
 * @author Kivanc Muslu
 * 
 */
public interface UpdateListener
{
    /**
     * Adds the event to the list.
     * @param event Event to be added.
     */
    public void addUpdateEvent(UpdateEvent event);
    
    /**
     * All events in the list is executed (their doEvent() method is called) by the listener. 
     * @see UpdateEvent#doEvent()
     */
    public void broadcast();
}
