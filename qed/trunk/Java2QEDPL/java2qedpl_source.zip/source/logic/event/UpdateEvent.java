package logic.event;

import logic.MethodTransformation;
import logic.TransformationExpression;

/**
 * {@link UpdateEvent} is used as the event that should be notified by the {@link MethodTransformation} before the transformation
 * of that method. <br>
 * Any {@link TransformationExpression} can implement this event, if it has to figure out something that is not present (or may
 * not be present) at the time of parsing (i.e., that part is not parsed yet).
 * 
 * @author Kivanc Muslu
 * 
 */
public interface UpdateEvent
{
    /**
     * All events must override this method to implement their event when the parsing is completed and the translation of the
     * {@link UpdateListener} (method) has started.
     */
    public void doEvent();
}
