package logic;

import java.util.ArrayList;

/**
 * {@link ShortCircuitAndTransformation} represents '&&' in Java. <br>
 * It has two elements: a list representing the first operand of '&&' and a list of list than represent the remaining operands.
 * Note: The second element (list of lists) must have at least one element (i.e., '&&' must have at least two operands). <br>
 * 
 * @author Kivanc Muslu
 */
public class ShortCircuitAndTransformation extends ShortCircuitTransformation
{
    /**
     * Passes the owner container first operand (exp1) and remaining operands (exp2) to {@link ShortCircuitTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param exp1 First operand of '&&'.
     * @param exp2 Remaining operands of '&&'.
     */
    protected ShortCircuitAndTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> exp1,
            ArrayList<TransformationExpressionList<TransformationExpression>> exp2)
    {
        super(owner, exp1, exp2);
    }
    
    /**
     * Only creates the first if statement of the translation. The translation is mostly done in the super class. <br>
     * <br>
     * <strong>Example Translation:</strong>
     * 
     * <pre>
     * boolean result = (3 &gt; 2) &amp;&amp; (node == null);
     * 
     * ==&gt; is translated to
     * 
     * var dummy: bool;
     * var result: bool;
     * 
     * dummy := (3 &gt; 2); // First operand is executed.
     * if (dummy)
     * {
     *          dummy := (node == null); // Second operand is executed iff the first one is true.
     * }
     * result := dummy;
     * 
     * </pre> {@inheritDoc}
     * 
     * @see #transformFirstExpression()
     * @see #transformSecondExpression()
     */
    public String realTransformation()
    {
        String firstTransformation = transformFirstExpression();
        String secondTransformation = transformSecondExpression();
        
        String result = "";
        result += firstTransformation;
        result += "if (" + getAlias() + ")\n";
        result += "{\n";
        result += secondTransformation;
        result += "}\n";
        
        return result;
    }
    
    /**
     * The second operand in '&&' executed iff the first one is {@code true}. So there is no condition for the dummy if created. <br>
     * <br>{@inheritDoc}
     */
    protected String getConditionPrefix()
    {
        return "";
    }
}
