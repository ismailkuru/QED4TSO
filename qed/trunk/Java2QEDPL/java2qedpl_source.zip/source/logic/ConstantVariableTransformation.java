package logic;

import syntaxtree.NodeToken;

/**
 * {@link ConstantVariableTransformation} represents the static final variables in Java. <br>
 * It has two elements: variableName represents the name of the variable, and assignedTo represents the assignment done to the
 * variable. <br>
 * 
 * @author Kivanc Muslu
 */
public class ConstantVariableTransformation extends VariableTransformation
{
    
    /**
     * Passes the owner container, name and assignment to {@link VariableTransformation}.
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected ConstantVariableTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
    }
    
    /**
     * Since this variable is final (i.e., cannot be changed), its assignment is translated as an axiom declaration in QED PL. <br>
     * <br> {@inheritDoc}
     */
    public String transformAssignment()
    {
        String result = "";
        result += "axiom (" + getCompletedVariableName() + " == " + getAssignedTo().transformCompletely() + ");\n";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = "";
        result += "const " + getCompletedVariableName() + ": " + getTypeName() + ";\n";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ConstantVariableTransformation: name = " + getName() + ", type = " + getType() + ", indentation = "
                + getIndentationLevel() + "]";
    }
}
