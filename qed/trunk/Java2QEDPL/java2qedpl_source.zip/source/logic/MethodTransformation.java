package logic;

import java.util.ArrayList;

import logic.annotation.JAVA2QEDPL;
import logic.event.UpdateEvent;
import logic.event.UpdateListener;

import syntaxtree.NodeToken;

/**
 * {@link MethodTransformation} represents methods in Java. <br>
 * It has three elements: name represents the method name, visibility represents the method visibility and isStatic is the flag
 * represents the method's static information <br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC. 
 * <br>
 * <strong>Field Summary:</strong> <br>
 * body_ - Sentences to be executed in the method (represented as {@link StatementTransformation}). <br>
 * arguments_ - Arguments that are needed to call the method (i.e., method signature) (represented as
 * {@link VariableTransformation}).<br>
 * returnType_ - Return type of the method. <br>
 * originalName_ & originalNameToken_ - Method's original name (since it will be changed to prevent the conflicts). <br>
 * events_ - {@code MethodTransformation} also implements {@link UpdateListener}. Events contain the event list of the method. <br>
 * transformation_ - With QED PL Annotation {@link JAVA2QEDPL}, one can ignore the whole method translation and give the
 * actual translation s/he wants as plain text. If this is the case, the translation is stored in this variable. (line by line) <br>
 * forStatementVariables_ - These variables must be declared at the beginning of the method, so they are stored. <br>
 * overridden_ - Set to true if the method is overridden (especially used for constructors). <br>
 * isStatic_ - Set to true if the method is static. <br>
 * counter_ - is used to keep track of the methods with the same name (overridden methods) (since they have to have different
 * names in QED PL). <br>
 * allMethods_ - is the list that keeps all methods declared in the program. <br>
 * preludeMethods_ - these methods are not defined the program but generally used in the program. Almost all of the represent
 * native or standard library methods, so they have to be hard-coded in QED (as prelude methods). These methods are only stored as
 * Prototypes. <br>
 * 
 * @author Kivanc Muslu
 * @see StatementTransformation
 * @see VariableTransformation
 * @see JAVA2QEDPL
 */
public class MethodTransformation extends ContainerTransformation implements UpdateListener
{
    private final ArrayList<StatementTransformation> body_;
    private final ArrayList<VariableTransformation> arguments_;
    private TypeTransformation returnType_;
    private final NodeToken originalNameToken_;
    private final String originalName_;
    private final String visibility_;
    private ArrayList<String> transformation_ = null;
    private ArrayList<String> forStatementVariables_ = new ArrayList<String>();
    private boolean overridden_ = false;
    private boolean isStatic_ = false;
    private int counter_ = 1;
    
    private ArrayList<UpdateEvent> events_;
    
    public static final ArrayList<MethodTransformation> allMethods_ = new ArrayList<MethodTransformation>();
    public static final ArrayList<MethodTransformation> preludeMethods_ = new ArrayList<MethodTransformation>();
    
    public static final boolean DEBUG_BODY = false;
    protected final static String RESULT_NAME = JAVA2QEDPL.RESULT;
    
    public MethodTransformation(ContainerTransformation owner, NodeToken name, String visibility, boolean isStatic)
    {
        super(owner, name, false);
        body_ = new ArrayList<StatementTransformation>();
        arguments_ = new ArrayList<VariableTransformation>();
        originalNameToken_ = name;
        originalName_ = originalNameToken_.tokenImage;
        visibility_ = visibility;
        events_ = new ArrayList<UpdateEvent>();
        isStatic_ = isStatic;
        
        addMethod(this);
    }
    
    /**
     * Only used for prelude methods. Prelude methods are not translated, they are only stored as prototypes.
     * 
     * @param name Name of the method.
     * @param arguments Arguments of the method.
     */
    private MethodTransformation(String name, VariableTransformation... arguments)
    {
        super(ClassTransformation.getMainClassTransformation(), new NodeToken(name), false);
        body_ = new ArrayList<StatementTransformation>();
        arguments_ = new ArrayList<VariableTransformation>();
        for (VariableTransformation arg : arguments)
            arguments_.add(arg);
        String originalName = name.split("_")[1];
        originalNameToken_ = new NodeToken(originalName);
        originalName_ = originalNameToken_.tokenImage;
        visibility_ = "public";
        events_ = new ArrayList<UpdateEvent>();
        
        preludeMethods_.add(this);
    }
    
    /**
     * Adds the prelude methods that I needed during the translation. This method can be richened later on. <br>
     * Called by {@link QEDVisitor} as an initialization before the whole translation process starts.
     * 
     * @see QEDVisitor#QEDVisitor(String)
     */
    public static void addPreludeMethods()
    {
        MethodTransformation threadCurrentThread = new MethodTransformation("Thread_currentThread");
        threadCurrentThread.setReturnType(new TypeTransformation(new NodeToken("Thread")));
        threadCurrentThread.isStatic_ = true;
        
        MethodTransformation threadYield = new MethodTransformation("Thread_yield");
        threadYield.setReturnType(new TypeTransformation(new NodeToken("void")));
        threadYield.isStatic_ = true;
        
        MethodTransformation threadInterrupted = new MethodTransformation("Thread_interrupted");
        threadInterrupted.setReturnType(new TypeTransformation(new NodeToken("bool")));
        threadInterrupted.isStatic_ = true;
    }
    
    /**
     * Returns {@code true} if the method is static, {@code false} otherwise.
     * 
     * @return {@code true} if the method is static, {@code false} otherwise.
     */
    public boolean isStatic()
    {
        return isStatic_;
    }
    
    /**
     * Adds for statement variable represented by 'variable'.
     * 
     * @param variable Variable name to be added as a for statement variable.
     * @see ForStatementTransformation#ForStatementTransformation(ContainerTransformation, TransformationExpressionList,
     *      TransformationExpressionList, TransformationExpressionList, TransformationExpressionList)
     */
    public void addForStatementVariable(String variable)
    {
        forStatementVariables_.add(variable);
    }
    
    /**
     * Returns the method that is specified by method name = originalMethodName, number of args. = arguments and arguments types =
     * types. <br>
     * Notice that this method is not complete for the moment and returns the <strong>last</strong> method when method name =
     * originalMethodName and number of args. = arguments. <br>
     * This is due to the fact that I couldn't implement and test full type check system internally, so I cannot check the types
     * of everything with 100% precision. <br>
     * Thus, there might be more than one correct result (internally) as the result of this method call. After the translation,
     * user must control the overridden methods. <br>
     * 
     * @param originalMethodName Original method name that is being searched.
     * @param arguments Number of arguments of the method being searched.
     * @param types Optional types of the arguments of the method being searched. Note: not used at the moment.
     * @return {@link MethodTransformation} that is specified by method name = originalMethodName, number of args. = arguments and
     *         arguments types = types.
     */
    public static MethodTransformation getMethodTransformation(String originalMethodName, int arguments,
            TypeTransformation... types)
    {
        // System.out.println("Searching the complete method name for: " + originalMethodName );
        ArrayList<MethodTransformation> all = new ArrayList<MethodTransformation>();
        all.addAll(allMethods_);
        all.addAll(preludeMethods_);
        MethodTransformation result = null;
        /* outer: */for (MethodTransformation method : all)
        {
            // System.out.println("Original method name: " + method.getOriginalName());
            if (method.getOriginalName().equals(originalMethodName) && method.getNoArguments() == arguments)
            {
                // for (int a = 0; a < types.length; a++)
                // {
                // System.out.println("Comparing: " + types[a] + ", " + method.arguments_.get(a).getType());
                // if (types[a] == null || method.arguments_.get(a).getType() == null)
                // {
                // if (types[a] != method.arguments_.get(a).getType())
                // continue outer;
                // }
                // else if (!types[a].equals(method.arguments_.get(a).getType()))
                // continue outer;
                // }
                // System.out.println("Found one: " + method.getCompleteName());
                result = method;
            }
        }
        
        return result;
    }
    
    /**
     * Sets the return type of the method.
     * 
     * @param type Return type of the method.
     */
    public void setReturnType(TypeTransformation type)
    {
        returnType_ = type;
    }
    
    /**
     * Returns the return type of the method.
     * 
     * @return The return type of the method.
     */
    protected TypeTransformation getReturnType()
    {
        return returnType_;
    }
    
    /**
     * Returns the number of arguments of the method.
     * 
     * @return The number of arguments of the method.
     */
    public int getNoArguments()
    {
        return arguments_.size();
    }
    
    /**
     * {@inheritDoc} <br>
     * <br>
     * This method also returns true in case the variable 'variableName' is matches one of the arguments of the method.
     */
    protected boolean containsVariableDeclaration(String variableName)
    {
        boolean result1 = super.containsVariableDeclaration(variableName);
        if (result1)
            return true;
        for (VariableTransformation variable : arguments_)
        {
            if (variable.getName().equals(variableName))
                return true;
        }
        for (String forVariable : forStatementVariables_)
        {
            if (forVariable.equals(variableName))
                return true;
        }
        
        return false;
    }
    
    /**
     * {@inheritDoc} <br>
     * <br>
     * This method also returns the {@link VariableTransformation} that represents the variable represented by 'variableName' if
     * it is matches one of the arguments of the method.
     */
    protected VariableTransformation getVariableDeclaration(String variableName)
    {
        VariableTransformation result = super.getVariableDeclaration(variableName);
        if (result != null)
            return result;
        for (VariableTransformation variable : arguments_)
        {
            if (variable.getName().equals(variableName))
                return variable;
        }
        return null;
    }
    
    /**
     * Sets transformation equilavent of this method. This is copied as the body of the method.
     * 
     * @param transformation List of strings that represent the transformation of the method (one line per string)
     */
    public void setTransformation(ArrayList<String> transformation)
    {
        transformation_ = transformation;
    }
    
    /**
     * Returns the original name (as used in Java code) of the method.
     * 
     * @return The original name (as used in Java code) of the method.
     */
    protected String getOriginalName()
    {
        return originalName_;
    }
    
    /**
     * Return the original name appended at the end of the class name with '_'.
     * 
     * @return The original name appended at the end of the class name with '_'.
     */
    protected String getOriginalCompleteName()
    {
        return getOwner().getName() + "_" + originalName_;
    }
    
    /**
     * Returns {@code true} if the method is overridden, {@code false} otherwise.
     * 
     * @return {@code true} if the method is overridden, {@code false} otherwise.
     */
    protected boolean isOverridden()
    {
        return overridden_;
    }
    
    /**
     * Adds the method to all methods list. <br>
     * This method also updates the name of the method with a new post-fix (a number, counter_) if there is already a method with
     * the same name defined.
     * 
     * @param method Method to be added to the list.
     */
    private static void addMethod(MethodTransformation method)
    {
        for (MethodTransformation md : allMethods_)
        {
            if (md.getName().equals(method.getName()))
            {
                md.counter_++;
                method.counter_ = md.counter_;
                method.updateName(method.getName() + "_" + method.counter_);
                method.overridden_ = true;
                break;
            }
        }
        allMethods_.add(method);
    }
    
    /**
     * Adds body statement represented with 'st' to the method.
     * 
     * @param st Body statement to be added.
     */
    public void addBodyStatement(StatementTransformation st)
    {
        body_.add(st);
    }
    
    /**
     * Adds argument represented with 'arg' to the method.
     * 
     * @param arg Argument to be added.
     */
    public void addArgumentTransformation(VariableTransformation arg)
    {
        arguments_.add(arg);
    }
    
    /**
     * Method's complete name is defined as: 'class_that_method_defined_in'_'method_name(after the update)'.
     * 
     * @return The complete name of the method.
     */
    protected String getCompleteName()
    {
        if (getOwner().equals(ClassTransformation.getMainClassTransformation()))
            return getName();
        else
            return getOwner().getName() + "_" + getName();
    }
    
    /**
     * Constructs and returns the translation where the variable declarations are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the variables declarations of the method).
     */
    protected String addVariableDeclarationsToCurrentTransformation(String current)
    {
        String result = current;
        String extra = "";
        for (VariableTransformation vd : getVariables())
            extra += vd.transformWithIndentation();
        if (!extra.trim().equals(""))
            result += extra + "\n";
        return result;
    }
    
    /**
     * Constructs and returns the translation where the variable assignments are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the variables assignments of the method).
     */
    protected String addVariableAssignmentsToCurrentTransformation(String current)
    {
        String result = current;
        String extra = "";
        for (VariableTransformation vd : getVariables())
            extra += vd.transformAssignmentWithIndentation();
        if (!extra.trim().equals(""))
            result += extra + "\n";
        return result;
    }
    
    /**
     * Constructs and returns the translation where the body statements are added to the current translation.
     * 
     * @param current Current translation represented as a String.
     * @return The resulting translation (which includes the translation of the body statements of the method).
     */
    protected String addBodyStatement(String current)
    {
        String result = current;
        for (StatementTransformation sd : body_)
        {
            if (sd instanceof VariableTransformation)
            {
                if (sd instanceof StaticVariableWithAssignmentTransformation
                        || sd instanceof VariableWithAssignmentTransformation)
                    result += sd.transformWithIndentation();
                // TODO seems unnecessary else statement.
                else
                    result += "";
            }
            else
                result += sd.transformWithIndentation();
        }
        
        return result;
    }
    
    /**
     * Translates the method translation up to the point where procedure is declared. <br>
     * This translation is split into 2 parts to implement the {@code ConstructorTransformation} easier.
     * 
     * @return The String representation of the first part of the translation.
     * @see ConstructorTransformation#transform()
     */
    protected String transformPart1()
    {
        String result = "";
        String atomicInfo = "";
        String visibilityInfo = "";
        String firstParam = "";
        if (transformation_ != null)
            atomicInfo = " {:isatomic true}";
        if (visibility_ != null && (visibility_.equals("public") || visibility_.equals("protected")))
            visibilityInfo = " {:ispublic true}";
        if (!isStatic_)
            firstParam = "this: " + getOwner().getName() + ", ";
        result += "procedure" + atomicInfo + visibilityInfo + " " + getCompleteName() + " (" + firstParam;
        for (VariableTransformation vd : arguments_)
        {
            String variableTransformation = vd.transformCompletely();
            result += variableTransformation.substring(4, variableTransformation.length() - 2) + ", ";
        }
        if (arguments_.size() > 0 || !isStatic_)
            result = result.substring(0, result.length() - 2);
        result += ")";
        if (returnType_ != null && !returnType_.transformCompletely().equals("void"))
            result += " returns (" + RESULT_NAME + ": " + returnType_.transformCompletely() + ")";
        result += "\n{\n";
        
        result = addVariableDeclarationsToCurrentTransformation(result);
        // result += transformPreTransformation();
        
        return result;
    }
    
    /**
     * Translates the body statements, variable declarations, variable assignments of the method. <br>
     * Notice that is transformation_ is not null, then it is used as the transformation. <br>
     * This translation is split into 2 parts to implement the {@code ConstructorTransformation} easier.
     * 
     * @return The String representation of the second part of the translation.
     * @see #transformPart1()
     * @see #transformation_
     */
    protected String transformPart2()
    {
        String result = "";
        if (transformation_ == null)
        {
            result = addVariableAssignmentsToCurrentTransformation(result);
            result = addBodyStatement(result);
        }
        else
        {
            for (String line : transformation_)
                result += "\t" + line + "\n";
        }
        result += "}\n";
        return result;
    }
    
    /**
     * Complete translation is done using the partial translations. <br>
     * <br>{@inheritDoc}
     * 
     * @see #transformPart1()
     * @see #transformPart2()
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        broadcast();
        String result = "";
        result += transformPart1();
        result += transformPart2();
        
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        String result = "[logic.MethodTransformation: name = " + getCompleteName() + ", indentation = " + getIndentationLevel()
                + "]";
        if (DEBUG_BODY)
        {
            for (StatementTransformation body : body_)
                result += "\n\tBODY: " + body;
        }
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public void broadcast()
    {
        for (UpdateEvent event : events_)
            event.doEvent();
    }
    
    /**
     * {@inheritDoc}
     */
    public void addUpdateEvent(UpdateEvent event)
    {
        events_.add(event);
    }
    
}
