package logic;

import syntaxtree.NodeToken;

/**
 * {@link VariableWithAssignmentTransformation} represents non-static variable declarations with assignment in Java. <br>
 * It has two elements: variableName which represents the name of the variable, and assignedTo that represents the assignment.<br>
 * Type is set later (cannot be set in the constructor) because of the structure of AST created by JavaCC.
 * 
 * @author Kivanc Muslu
 */
public class VariableWithAssignmentTransformation extends PlainVariableTransformation
{
    /**
     * Passes the owner container, variableName and assignment to {@link PlainVariableTransformation}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param variableName Name of the variable.
     * @param assignedTo Assignment of the variable.
     */
    protected VariableWithAssignmentTransformation(ContainerTransformation owner, NodeToken variableName,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, variableName, assignedTo);
    }
    
    /**
     * Transforms and returns the assignment part of the variable. <br>
     * <br>{@inheritDoc}
     * 
     * @see #transform()
     */
    public String transformAssignment()
    {
        String result = "";
        result += getName() + " := " + getAssignedTo().transformCompletely() + ";\n";
        return result;
    }
    
    /**
     * Overridden to create a new instance of the same translation. Because declaration can be modified and we don't want the
     * actual variable to be modified at the same time. <br>
     * <br>{@inheritDoc}
     */
    public VariableTransformation getDeclaration()
    {
        VariableTransformation result = new PlainVariableTransformation(getOwner(), getNameToken());
        result.setType(getType());
        return result;
    }
    
    /**
     * <strong>Example Translation (for VariableWithAssignmentTransformation):</strong>
     * 
     * <pre>
     * int counter = 5;
     * 
     * ==&gt; is translated to
     * 
     * var counter: int;
     * counter := 5;
     * </pre>
     * {@inheritDoc}
     * 
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        if (isOnlyAssignmentTransformation())
            return transformAssignment();
        else
            return super.transform();
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.VariableWithAssignmentTransformation: name = " + getName() + ", type = " + getType() + ", indentation = "
                + getIndentationLevel() + "]";
    }
}
