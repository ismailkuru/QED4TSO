package logic;

/**
 * {@link AssignmentTransformation} represents the assignments in Java. <br>
 * It has two elements: lhs represents the left hand side of the assignment, assignment represents the assignment. <br>
 * 
 * @author Kivanc Muslu
 */
public class AssignmentTransformation extends StatementTransformation
{
    private final TransformationExpression leftHandSide_;
    
    /**
     * Passes the owner container, left hand side and assignment to {@link StatementTransformation}, sets the container of left
     * hand side as {@code this}. <br>
     * Updates the lhs, declared as {@link VariableAccessTransformation} or {@link ArrayAccessTransformation} as left-hand-side. <br>
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param lhs Left hand side of the assignment.
     * @param assignment Right hand side of the assignment.
     */
    public AssignmentTransformation(ContainerTransformation owner, TransformationExpression lhs,
            TransformationExpressionList<TransformationExpression> assignment)
    {
        super(owner, null, assignment);
        leftHandSide_ = lhs;
        
        assignment.setContainer(this);
        lhs.setContainer(this);
        
        if (lhs instanceof ArrayAccessTransformation)
            ((ArrayAccessTransformation) lhs).makeLHS();
        else if (lhs instanceof VariableAccessTransformation)
            ((VariableAccessTransformation) lhs).makeLHS();
    }
    
    /**
     * Returns the translation of the left hand side in the assignment.
     * @return The translation of the left hand side in the assignment.
     */
    protected String transformLHS()
    {
        return leftHandSide_.transformCompletely();
    }
    
    /**
     * Returns the translation of the right hand side in the assignment.
     * @return The translation of the right hand side in the assignment.
     */
    protected String transformRHS()
    {
        return getAssignedTo().transformCompletely();
    }
    
    /**
     * {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = transformLHS() + " := " + transformRHS() + "";
        return result;
    }
    
    public String toString()
    {
        return "[logic.AssignmentTransformation: name = " + leftHandSide_.getName() + ", indentation = " + getIndentationLevel()
                + "]";
    }
}
