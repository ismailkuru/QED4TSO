package logic;

/**
 * {@link PlainStatementTransformation} represents statements that can be translated directly from Java to QED PL (i.e. 3 + 2). <br>
 * It has one elements: a list of {@link TransformationExpression} that represents the statement. <br>
 * noArgs is actually derived (it is arguments.size()).
 * 
 * @author Kivanc Muslu
 */
public class PlainStatementTransformation extends StatementTransformation
{
    private int dummy;
    
    /**
     * Passes the owner container and 'statement' (as a representation of assignedTo) to {@link StatementTransformation}. <br>
     * Sets the container of statement as {@code this}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param statement List of transformation expressions representing the statement.
     */
    public PlainStatementTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> statement)
    {
        super(owner, null, statement);
        statement.setContainer(this);
    }
    
    /**
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String result = getAssignedTo().transformCompletely();
        if (result.trim().startsWith("dummy_"))
        {
            String right = result.split("dummy_")[1];
            try
            {
                Integer.parseInt(right);
                result = "";
            }
            catch (Exception e)
            {}
        }
        if (!result.equals(""))
            result += ";\n";
        
        // return result.trim();
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.PlainStatementTransformation: indentation = " + getIndentationLevel() + "]";
    }
    
}
