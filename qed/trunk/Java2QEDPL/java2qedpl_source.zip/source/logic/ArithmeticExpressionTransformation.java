package logic;

/**
 * 
 * {@link ArithmeticExpressionTransformation} represents the translation of any basic arithmetic expression in Java. <br>
 * It is created by a list of transformation expressions which represents its contents (elements and operators). <br>
 * Theoretically, this list should contain an element, an operator, an element, ... an so on. Its size must be greater than 2. <br>
 * <br>
 * <strong>An example representation:</strong> <br>
 * 3 + 2 - 4 ==> should be represented with the following list <br> {@link TransformationExpressionList} with elements: <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;{@link LiteralTransformation}: 3 <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;{@link LiteralTransformation}: + <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;{@link LiteralTransformation}: 2 <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;{@link LiteralTransformation}: - <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;{@link LiteralTransformation}: 4 <br>
 * 
 * @author Kivanc Muslu.
 * 
 */
public class ArithmeticExpressionTransformation extends TransformationExpression
{
    private final TransformationExpressionList<TransformationExpression> elements_;
    
    /**
     * Passes the owner container to {@link TransformationExpression}, sets the elements and assigns {@code this} as
     * the container of elements. <br>
     * 
     * @param owner Owner container (method or class) of this expression.
     * @param elements Internal representation of this arithmetic expression.
     */
    protected ArithmeticExpressionTransformation(ContainerTransformation owner,
            TransformationExpressionList<TransformationExpression> elements)
    {
        super(owner);
        elements_ = elements;
        
        elements_.setContainer(this);
    }
    
    /**
     * The type of the arithmetic expression is specified by its elements. All elements' types are combined iteratively to find
     * out the result type. <br>
     * Example: <br>
     * 3 + 2.5 - 4 ==> will be processed as following: <br>
     * 3: Result type is 'int' <br>
     * 2.5: Result type is 'float' (combination of 'int' and 'float') <br>
     * 4: Result type is 'float' (combination of 'float' and 'int') <br>
     * 
     * {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        TypeTransformation result = elements_.getElementAt(0).getType();
        for (int a = 2; a < elements_.getSize(); a += 2)
            result = TypeTransformation.combineTwoTypes(result, elements_.getElementAt(a).getType());
        
        return result;
    }
    
    /**
     * Transformation of the {@link ArithmeticExpressionTransformation} is done with the following steps: <br>
     * <ul>
     * <li>Transform the elements_ list (all elements and operators)</li>
     * </ul> 
     * <br> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        return elements_.transformCompletely();
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.ArithmeticExpressionTransformation: indentation = " + getIndentationLevel() + "]";
    }
    
}
