package logic;

import java.util.ArrayList;

import syntaxtree.NodeToken;

/**
 * {@link ContainerTransformation} is the abstract representation for containers (that can contain variables) in java. These are:
 * {@link MethodTransformation} and {@link ClassTransformation}.<br>
 * It has two elements: name representing the constructor name, and visibility representing the visibility (public, private,
 * package, protected) <br>
 * 
 * @author Kivanc Muslu
 */
public abstract class ContainerTransformation extends TransformationExpression
{
    private final ArrayList<VariableTransformation> variables_;
    
    private static int dummyCounter = 0;

    private boolean tolookafter;
    
    /**
     * Passes the owner container, and name to {@link TransformationExpression}.
     * 
     * @param owner Owner container of this expression.
     * @param name Name of this container.
     * @param indent Flag that decides weather this container should be indented (while writing to the output file) with respect
     *        to its owner or not.
     */
    protected ContainerTransformation(ContainerTransformation owner, NodeToken name, boolean indent)
    {
        super(owner, name, indent);
        
        variables_ = new ArrayList<VariableTransformation>();
    }
    
    /**
     * Passes the owner container to {@link TransformationExpression}. <br>
     * Only to be called by MAIN_CLASS_DECLARATION.
     * @see ClassTransformation
     * 
     * @param name Name of this container.
     */
    protected ContainerTransformation(String name)
    {
        super(name);
        variables_ = new ArrayList<VariableTransformation>();
    }
    
    /**
     * Containers are defined as typeless. <br>
     * <br>{@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return TypeTransformation.TYPELESS;
    }
    
    /**
     * Adds a dummy variable to this container and returns the name that represent the dummy variable.
     * @param type Type of the dummy variable to be created.
     * @return The {@link NodeToken} representation (used as String) of the newly created dummy variable.
     */
    protected NodeToken addDummyVariable(String type)
    {
        NodeToken typeToken = new NodeToken(type);
        NodeToken nameToken = new NodeToken("dummy_" + dummyCounter);
        dummyCounter++;
        VariableTransformation vt = new PlainVariableTransformation(this, nameToken);
        TypeTransformation typeTransformation = new TypeTransformation(typeToken);
        vt.setType(typeTransformation);
        addVariableTransformation(vt);
        return nameToken;
    }
    
    /**
     * Returns {@code true} if the variable represented by 'variableName' is contained, {@code false} otherwise. 
     * @param variableName String that represents the variable.
     * @return {@code true} if the variable represented by 'variableName' is contained, {@code false} otherwise. 
     */
    protected boolean containsVariableDeclaration(String variableName)
    {
        for (VariableTransformation variable : variables_)
        {
            if (variable.getName().equals(variableName))
                return true;
        }
        return false;
    }
    
    /**
     * Returns {@link VariableTransformation} that represents the variable represented by 'variableName' if contained, {@code null} otherwise. 
     * @param variableName String that represents the variable.
     * @return {@link VariableTransformation} that represents the variable represented by 'variableName' if contained, {@code null} otherwise. 
     */
    protected VariableTransformation getVariableDeclaration(String variableName)
    {
        for (VariableTransformation variable : variables_)
        {
            if (variable.getName().equals(variableName))
                return variable;
        }
        return null;
    }
    
    /**
     * Adds the variable to the container.
     * @param vt {@link VariableTransformation} that represents the variable to be added.
     */
    public void addVariableTransformation(VariableTransformation vt)
    {
        variables_.add(vt);
    }
    
    /**
     * Returns the variables contained in this container.
     * @return The variables contained in this container.
     */
    protected ArrayList<VariableTransformation> getVariables()
    {
        return variables_;
    }
    
    public String transform()
    {
        String result = "";
        for (VariableTransformation vd : variables_)
            result += vd.transformWithIndentation();
        result += "\n";
        for (VariableTransformation vd : variables_)
            result += vd.transformAssignmentWithIndentation();
        
        result += "\n";
        
        return result;
    }
}
