package logic;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * {@link TransformationExpressionList} is more of an internal data structure. It can be seen as an {@link ArrayList} of
 * {@link TransformationExpression} with some extra built-in methods. <br>
 * It is written with generic type so that anything that is subclass of TransformationExpression can have a dedicated list. <br>
 * 
 * @author Kivanc Muslu
 */
public class TransformationExpressionList<Type extends TransformationExpression> extends TransformationExpression implements
        Iterable<Type>
{
    private ArrayList<Type> elements_;
    
    /**
     * Initializes the array.
     */
    public TransformationExpressionList()
    {
        super("None");
        elements_ = new ArrayList<Type>();
    }
    
    /**
     * Adds element represented by 'elt' and sets its container {@code this} is not {@code null}.
     * 
     * @param elt Expression to be added to the list.
     */
    public void addElement(Type elt)
    {
        elements_.add(elt);
        if (elt != null)
            elt.setContainer(this);
    }
    
    /**
     * Return type of a transformation list is defined as the combination type of its all elements. <br>
     * <br>{@inheritDoc}
     * 
     * @see TypeTransformation#combineTwoTypes(TypeTransformation, TypeTransformation)
     */
    protected TypeTransformation getType()
    {
        if (elements_.size() == 0)
            return TypeTransformation.NONE_TYPE;
        
        TypeTransformation result = elements_.get(0).getType();
        for (Type elt : elements_)
            result = TypeTransformation.combineTwoTypes(result, elt.getType());
        
        return result;
    }
    
    /**
     * Transformation lists do not translate their pre-translation (since these translation passed to the container of the list
     * when added. So only the container of the list translates it). <br>
     * <br> {@inheritDoc}
     */
    public boolean addPreTransformation()
    {
        return false;
    }
    
    /**
     * Since all pre-translations added to the list is passed to the container of the list, when clear is called, these
     * pre-translations (the ones coming from the list) are also cleared from the container. <br>
     * <br> {@inheritDoc}
     */
    protected void clearPreTransformation()
    {
        ArrayList<String> preTransformation = getPreTransformation();
        
        if (getContainer() != null)
        {
            for (String s : preTransformation)
                getContainer().clearPreTransformation(s);
        }
        super.clearPreTransformation();
    }
    
    /**
     * Adds the pre-initialization also to the container of the list (if is not {@code null}). <br>
     * This is required since the whole list represents one line in Java, then we don't want the pre-translations to be written in
     * the middle of the sentence. <br>
     * <br>
     * <strong>Example wrong translation (if there were no passing to the container of the list):</strong>
     * 
     * <pre>
     * int newCounter = 3 + getCounter(); // Assume that getCounter() returns int and declared in MyClass
     * 
     * ==&gt; is wrongly translated to
     * 
     * var newCounter: int;
     * var dummy; int;
     * 
     * newCounter := 3 + call dummy := MyClass_getCounter();
     * dummy;
     * </pre>
     * 
     * <strong>Example correct translation (after passing to the container of the list):</strong>
     * 
     * <pre>
     * int newCounter = 3 + getCounter(); // Assume that getCounter() returns int and declared in MyClass
     * 
     * ==&gt; is translated to
     * 
     * var newCounter: int;
     * var dummy; int;
     * 
     * call dummy := MyClass_getCounter();
     * newCounter := 3 + dummy;
     * </pre>
     * 
     * {@inheritDoc}
     * 
     */
    protected void addPreInitialization(String s)
    {
        if (getContainer() != null)
        {
            getContainer().addPreInitialization(s);
            // super.addPreInitialization(s);
        }
        else
            QEDVisitor.writeErrorLog("Cannot add pre initialization to container for transformation: " + this
                    + ", since the container is NULL. ");
    }
    
    /**
     * {@inheritDoc}
     * @see #addPreInitialization(String)
     */
    protected void addPreTransformation(String s, TransformationExpression te)
    {
        if (getContainer() != null)
        {
            getContainer().addPreTransformation(s);
            super.addPreTransformation(s);
        }
        else
            QEDVisitor.writeErrorLog("Cannot add pre transformation: " + s + " to container for transformation: " + this
                    + ", since the container is NULL.\nComing from transformation of: " + te);
    }
    
    /**
     * {@inheritDoc}
     * @see #addPreInitialization(String)
     */
    protected void addPreTransformation(String s)
    {
        if (getContainer() != null)
        {
            getContainer().addPreTransformation(s);
            super.addPreTransformation(s);
        }
        else
            QEDVisitor.writeErrorLog("Cannot add pre transformation to container for transformation: " + this
                    + ", since the container is NULL.");
    }
    
    /**
     * Translation of an expression list is done by tranlating each element in the list one by one (with respect to the adding order). <br>
     * <br>{@inheritDoc}
     */
    public String transform()
    {
        String result = "";
        for (TransformationExpression exp : elements_)
        {
            String transformation = exp.transformCompletely();
            if (transformation.equals(""))
                continue;
            result += transformation;
            if (!result.endsWith("\n"))
                result += " ";
        }
        if (result.length() > 0 && result.endsWith(" "))
            result = result.substring(0, result.length() - 1);
        
        return result;
    }
    
    /**
     * Returns the element at 'index'.
     * @param index Index of the element to be returned.
     * @return The element at 'index'.
     */
    protected Type getElementAt(int index)
    {
        return elements_.get(index);
    }
    
    /**
     * Removes the last element, if there is any.
     */
    public void removeLast()
    {
        if (elements_.size() > 0)
            elements_.remove(elements_.size() - 1);
    }
    
    /**
     * Returns the size of the list.
     * @return The size of the list.
     */
    public int getSize()
    {
        return elements_.size();
    }
    
    /**
     * Returns the last element if exists, {@code null} otherwise.
     * @return The last element if exists, {@code null} otherwise.
     */
    public Type getLast()
    {
        if (elements_.size() > 0)
            return elements_.get(getSize() - 1);
        return null;
    }
    
    /**
     * Appends the expression list expressed by 'list' at the end of {@code this}.
     * @param list Expression list to be appended to {@code this}.
     */
    public void addList(TransformationExpressionList<Type> list)
    {
        for (Type te : list.elements_)
            addElement(te);
    }
    
    /**
     * Returns all elements in the list.
     * @return All elements in the list.
     */
    protected ArrayList<Type> getList()
    {
        return elements_;
    }
    
    /**
     * Changes the last elements in the list with 'newExpression'.
     * @param newExpression New expression that will take the last index (by deleting the old last).
     */
    protected void changeLast(Type newExpression)
    {
        if (elements_.size() > 0)
            elements_.remove(getSize() - 1);
        addElement(newExpression);
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        String result = "[logic.TransformationExpressionList] with elements:\n";
        for (TransformationExpression exp : elements_)
            result += "\t" + exp + "\n";
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public Iterator<Type> iterator()
    {
        Iterator<Type> result = elements_.iterator();
        return result;
    }
}
