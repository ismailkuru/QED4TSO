package logic;

import syntaxtree.NodeToken;

/**
 * {@link StatementTransformation} is an abstract representation for any statement in Java. <br>
 * It has two elements: name represents the name for variable declarations and assignedTo is a list of transformation expression
 * that can mean different things for different concrete classes. <br>
 * 
 * @author Kivanc Muslu
 */
public abstract class StatementTransformation extends TransformationExpression
{
    private final TransformationExpressionList<TransformationExpression> assignedTo_;
    
    /**
     * Passes the owner container to {@link TransformationExpression}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param name Name of the variable. 
     */
    protected StatementTransformation(ContainerTransformation owner, NodeToken name)
    {
        this(owner, name, null);
    }
    
    /**
     * Passes the owner container to {@link TransformationExpression}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param name Name of the variable.
     * @param assignedTo A list of transformation expression that can represent different things for different concrete classes. 
     */
    protected StatementTransformation(ContainerTransformation owner, NodeToken name,
            TransformationExpressionList<TransformationExpression> assignedTo)
    {
        super(owner, name, true);
        assignedTo_ = assignedTo;
        if (assignedTo_ != null)
            assignedTo_.setContainer(this);
    }
    
    /**
     * Returns assignedTo list.
     * @return assignedTo list.
     */
    protected TransformationExpressionList<TransformationExpression> getAssignedTo()
    {
        return assignedTo_;
    }
    
    /**
     * Statements are defined as typeless. Sub-classes might override this method if needed. <br>
     * <br>
     * {@inheritDoc}
     */
    protected TypeTransformation getType()
    {
        return TypeTransformation.TYPELESS;
    }
}
