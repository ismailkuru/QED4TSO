package logic;

/**
 * {@link Aux} is the Auxiliary class that contains some helper static methods. <br>
 * @author Kivanc Muslu
 *
 */
public class Aux
{   
    public static final boolean DEBUG_TRANSLATION_TRAVERSAL = true;
    
    /**
     * Appends the prefix at the beginning of the word and returns the new string without breaking the tab information of the original word.
     * @param word Word that the prefix will be attacked to.
     * @param prefix Prefix that will be attached to the word.
     * @return The concatenated string.
     */
    protected static String appendBeginning(String word, String prefix)
    {
        String result = "";
        int a;
        for (a = 0; a < word.length(); a++)
        {
            if (word.charAt(a) == '\t')
                result += "\t";
            else
                break;
        }
        result += prefix + word.substring(a);
        return result;
    }
    
    /**
     * Prints the traversal debug information if DEBUG_TRANSLATION_TRAVERSAL bit is set to {@code true}.
     * @param obj Object that will be printed for debugging.
     */
    public static void printDebugTraversal(Object obj)
    {
        printDebug(obj, DEBUG_TRANSLATION_TRAVERSAL);
    }
    
    /**
     * Helper method to print debug messages.
     * @param obj Object that will be printed for debugging.
     * @param flag Boolean flag that decides weather the information will be printed or not.  
     */
    private static void printDebug(Object obj, boolean flag)
    {
        if (flag)
            System.out.println(obj);
    }
}
