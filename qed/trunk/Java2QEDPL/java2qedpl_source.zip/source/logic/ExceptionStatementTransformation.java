package logic;

/**
 * {@link ExceptionStatementTransformation} represents the {@link Exception} in Java. <br>
 * It has one elements: type represents the type of the exception. <br>
 * 
 * @author Kivanc Muslu
 */
public class ExceptionStatementTransformation extends StatementTransformation
{
    private TypeTransformation type_;

    /**
     * Passes the owner container, and name to {@link StatementTransformation}. <br>
     * Newly created exception is also added as a const unique to MAIN_CLASS_DECLARATION. (so it will be defined in the output .bpl file before it is used)
     * @see ClassTransformation
     * 
     * @param owner Owner container of this expression.
     * @param type Type of the exception.
     */
    protected ExceptionStatementTransformation(ContainerTransformation owner, TypeTransformation type)
    {
        super(owner, null);
        type_ = type;
        
        ClassTransformation.addNewException(type_.transform());
    }

    /**
     * Returns the type of the exception.
     * @return The type of the exception.
     */
    public TypeTransformation getType()
    {
        return type_;
    }
    
    /**
     * Returns the translation of this exception.
     * @return The translation of this exception.
     */
    public String transform()
    {
        return "throw " + type_.transform() + ";";
    }   
    
}
