package logic;

/**
 * {@link TryBlockTransformation} represents 'try ... finally' in Java. <br>
 * It has three elements: body represents the statements to be executed in the {@code try} block, and finallyBody represents the
 * statements to be executed in the {@code finally} block. <br>
 * 
 * @author Kivanc Muslu
 */
public class TryBlockTransformation extends StatementTransformation
{
    private TransformationExpressionList<StatementTransformation> body_;
    private TransformationExpressionList<StatementTransformation> finallyBody_;
    
    /**
     * 
     * Passes the owner container, and condition to {@link TransformationExpression}. <br>
     * Sets the container of body and finallyBody as {@code this}. <br>
     * 
     * @param owner Owner container of this expression.
     * @param body Statements to be executed in {@code try} block.
     * @param finallyBody Statements to be executed in {@code finally} block.
     */
    protected TryBlockTransformation(ContainerTransformation owner, TransformationExpressionList<StatementTransformation> body,
            TransformationExpressionList<StatementTransformation> finallyBody)
    {
        super(owner, null);
        body_ = body;
        finallyBody_ = finallyBody;
        
        finallyBody_.setContainer(this);
        body_.setContainer(this);
    }
    
    /**
     * Try ... finally ... is translated as a syntactic sugar to try ... catch ... in QED PL. <br>
     * In QED PL if you don't specify a type in catch, it catches any exception (which is the same thing that finally does). <br>
     * <br>
     * <strong>Sample translation (TryBlockExpression):</strong>
     * 
     * <pre>
     * int a;
     * try
     * {
     *          a = 3;
     * }
     * finally
     * {
     *          a++;
     * }
     * 
     * ==&gt; is translated to
     * 
     * var a: int;
     * try
     * {
     *          a :=3;
     * }
     * catch    // Will be executed if any exception is thrown. 
     * {
     *          a := a + 1;
     *          throw ex; // re-throw the last exception.
     * }
     * a := a + 1;      // since we want 'a' to be incremented in case there is no exception at all.
     * </pre> {@inheritDoc}
     */
    public String transform()
    {
        Aux.printDebugTraversal(this);
        String bodyTransformation = body_.transformCompletely();
        String finallyBodyTransformation = finallyBody_.transformCompletely();
        
        String result = "";
        result += "try\n";
        result += "{\n";
        for (String s : bodyTransformation.split("\n"))
        {
            s = s.replace("return;", "throw ExReturn;");
            result += "\t" + s + "\n";
        }
        result += "}\n";
        result += "catch\n";
        result += "{\n";
        for (String s : finallyBodyTransformation.split("\n"))
            result += "\t" + s + "\n";
        result += "\tthrow ex;\n";
        result += "}\n";
        result += finallyBodyTransformation;
        return result;
    }
    
    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "[logic.TryBlockTransformation]";
    }
}
