import logic.QEDVisitor;
import syntaxtree.CompilationUnit;

public class Java2QEDPL
{
    /**
     * Java2QEDPL library call. Translates the input programs written in Java to output program written in QED PL. <br>
     * If the method is called with 'n' arguments, then the first 'n-1' arguments are taken as input files, and the last argument
     * is taken as the output file. <br>
     * Input files must be in the given location (relative or absolute), output file might not be created before the
     * execution (program can create it, if not exists). However the folders to access the output file must be created before
     * hand. If the output file already exists, then it is overwritten. <br>
     * There must be at least 2 arguments when calling this method (an input and an output). Otherwise it shows the usage string
     * and returns (without doing anything). <br>
     * <br>
     * <strong>Example Calls:</strong> <br>
     * Java2QEDPL.translate("AtomicBoolean.java", "AtomicBoolean.bpl"); // Translate the program inside AtomicBoolean.java to QED
     * PL and name the output file as AtomicBoolean.bpl. <br>
     * Java2QEDPL.translate("AbstractQueuedSynchronizer.java", "AbstractOwnableSyncrhonizer.java", "LockSupport.java", "AQS.bpl");
     * // Translate the program that is represented by the first 3 java files to QED PL and name the output as AQS.bpl.
     * 
     * @param args Arguments that represents the inputs files and output file.
     */
    public static void translate(String... args)
    {
        JavaParser parser;
        if (args.length >= 2)
        {
            QEDVisitor v = new QEDVisitor(args[args.length - 1]);
            for (int a = 0; a < args.length - 1; a++)
            {
                System.out.println("Java 2 QED PL Version 0.9:  Reading from file " + args[a] + " . . .");
                
                try
                {
                    parser = new JavaParser(new java.io.FileInputStream(args[a]));
                }
                catch (java.io.FileNotFoundException e)
                {
                    System.out.println("Java 2 QED PL Version 0.9:  File " + args[a] + " not found.");
                    continue;
                }
                
                try
                {
                    CompilationUnit cu = parser.CompilationUnit();
                    cu.accept(v);
                    System.out.println("Java 2 QED PL Version 0.9:  Java program parsed successfully.");
                }
                catch (ParseException e)
                {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                    System.out.println("Java 2 QED PL Version 0.9:  Encountered errors during parse.");
                }
            }
            v.endTransformation();
        }
        else if (args.length < 2)
        {
            System.out
                    .println("Java 2 QED PL Version 0.9 usage: java -jar java2qedpl.jar <input-file-1> <input-file-2> ... <input-file-n> <output-file>");
            System.out.println("You have to specify at least one input and one output file to the program.");
        }
    }
    // public static void main(String [] args)
    // {
    // String TOP = "/Users/kmuslu/Desktop/JAVA2QEDPL Test/atomic/";
    // String [] test = {TOP + "AB.java", TOP + "deneme.txt"};
    // JAVA2QEDPL.translate(test);
    // }
}
